extends Node3D

# Parámetros de equilibrio: editables en el Inspector al seleccionar el nodo Main.
@export var deuda_inicial: float = 150.0
@export var deuda_limite: float = 300.0
@export var interes_por_visita: float = 0.10
@export var tiempo_deuda: float = 120.0          # segundos hasta que llega el cobrador
@export var paciencia_cobrador: float = 60.0     # segundos que espera ante la puerta
@export var cuota_pago: float = 35.0
@export var penalizacion_deuda: float = 30.0
@export var bloqueo_olla_segundos: float = 30.0
@export var monedas_iniciales: int = 40
@export var liebres_iniciales: int = 2
@export var precio_liebre: int = 5
@export var precio_racion: int = 14
@export var raciones_por_guiso: int = 4
@export var sospecha_por_exceso: float = 60.0
@export var sospecha_por_captura: float = 4.0    # sospecha pasiva por cada gato cazado
@export var bajada_sospecha_servicio: float = 15.0

@onready var tavern = $Tavern
@onready var player = $Player
@onready var ui = $UI

var dia := 1
var monedas := 0
var deuda := 0.0
var sospecha := 0.0
var gatos := 0
var liebres := 0
var terminado := false

var especia_nombre := ""
var especia_reduccion := 0.0

var tiempo_restante := 0.0
var paciencia_restante := 0.0
var interes_ultima_visita := 0.0

var olla_actual = null      # olla cuyo menú de cocina está abierto
var olla_servicio = null    # olla de la que se sirve a los clientes

func _ready() -> void:
	monedas = monedas_iniciales
	deuda = deuda_inicial
	liebres = liebres_iniciales
	tiempo_restante = tiempo_deuda
	for n in get_tree().get_nodes_in_group("interactuable"):
		n.interactuado.connect(_on_interactuado)
	for t in get_tree().get_nodes_in_group("trampas"):
		t.gato_atrapado.connect(_on_gato_atrapado)
	ui.cocinar_solicitado.connect(_on_cocinar_solicitado)
	ui.cocina_cerrada.connect(_cerrar_menus)
	ui.pagar_solicitado.connect(_on_pagar)
	ui.entregar_solicitado.connect(_on_entregar)
	ui.cobrador_cerrado.connect(_cerrar_menus)
	ui.mejora_solicitada.connect(_on_mejora_solicitada)
	ui.mejoras_cerradas.connect(_cerrar_menus)
	ui.reinicio_solicitado.connect(_reiniciar)
	_refrescar_hud()
	ui.mostrar_mensaje("Caza gatos (o usa las trampas), cocina y sirve. ¡Y vigila al cobrador de la mafia!", 6.0)

func _process(delta: float) -> void:
	if terminado:
		ui.mostrar_prompt("")
		return
	_actualizar_cobrador(delta)
	if ui.hay_menu_abierto():
		ui.mostrar_prompt("")
		return
	var o = player.objetivo
	ui.mostrar_prompt(o.get_prompt() if is_instance_valid(o) else "")

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and not terminado:
		if ui.hay_menu_abierto():
			_cerrar_menus()
		elif Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		else:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

# ───────────────────────── Interacciones ─────────────────────────
func _on_interactuado(obj) -> void:
	if terminado:
		return
	match obj.tipo:
		"olla":
			_usar_olla(obj)
		"despensa":
			_comprar_liebre()
		"gato":
			_capturar_gato(obj)
		"cliente":
			_servir_cliente(obj)
		"trampa":
			_recoger_trampa(obj)
		"especia":
			_coger_especia(obj)
		"cobrador":
			_abrir_cobrador()
		"mejoras":
			_abrir_mejoras()

func _abrir_menu() -> void:
	player.set_controles(false)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _cerrar_menus() -> void:
	ui.cerrar_todos()
	olla_actual = null
	if not terminado:
		player.set_controles(true)
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

# ───────────────────────── Cocina y especias ─────────────────────────
func _usar_olla(olla) -> void:
	if olla.bloqueada():
		ui.mostrar_mensaje("La olla está bloqueada %d s más." % int(ceil(olla.bloqueo_restante)))
		return
	if especia_nombre != "":
		if olla.raciones <= 0:
			ui.mostrar_mensaje("Primero cocina un guiso al que echarle %s." % especia_nombre)
			return
		olla.reducir_sospecha(especia_reduccion)
		ui.mostrar_mensaje("Echas %s: la sospecha del guiso baja al %d%%." % [especia_nombre, int(round(olla.sospecha_acumulada * 100.0))])
		especia_nombre = ""
		especia_reduccion = 0.0
		_refrescar_hud()
		return
	if olla.raciones > 0:
		_marcar_servicio(olla)
		ui.mostrar_mensaje("Servirás desde esta olla (%d raciones)." % olla.raciones)
		return
	olla_actual = olla
	_abrir_menu()
	ui.abrir_cocina(gatos, liebres, raciones_por_guiso)

func _on_cocinar_solicitado(proporcion: float) -> void:
	if olla_actual == null:
		return
	var g := int(round(proporcion * raciones_por_guiso))
	var l := raciones_por_guiso - g
	if gatos < g:
		ui.mostrar_mensaje("Te faltan raciones de gato (necesitas %d)." % g)
		return
	if liebres < l:
		ui.mostrar_mensaje("Te falta liebre (necesitas %d). Cómprala en la despensa." % l)
		return
	gatos -= g
	liebres -= l
	olla_actual.cocinar(raciones_por_guiso, float(g) / float(raciones_por_guiso))
	_marcar_servicio(olla_actual)
	_cerrar_menus()
	_refrescar_hud()
	ui.mostrar_mensaje("Guiso listo: %d%% gato. Échale especias para bajar la sospecha." % int(round(proporcion * 100.0)))

func _marcar_servicio(olla) -> void:
	olla_servicio = olla
	for o in get_tree().get_nodes_in_group("ollas"):
		o.marcar_servicio(o == olla)

func _olla_con_guiso():
	if olla_servicio != null and olla_servicio.activa and olla_servicio.raciones > 0 and not olla_servicio.bloqueada():
		return olla_servicio
	for o in get_tree().get_nodes_in_group("ollas"):
		if o.activa and o.raciones > 0 and not o.bloqueada():
			return o
	return null

func _coger_especia(frasco) -> void:
	if especia_nombre != "":
		ui.mostrar_mensaje("Ya llevas %s. Échalo en una olla primero." % especia_nombre)
		return
	if monedas < frasco.precio:
		ui.mostrar_mensaje("No tienes monedas para %s (%d)." % [frasco.nombre, frasco.precio])
		return
	monedas -= frasco.precio
	especia_nombre = frasco.nombre
	especia_reduccion = frasco.reduccion
	_refrescar_hud()
	ui.mostrar_mensaje("Coges %s. Llévalo a una olla con guiso." % frasco.nombre)

func _comprar_liebre() -> void:
	if monedas < precio_liebre:
		ui.mostrar_mensaje("No tienes monedas para comprar liebre.")
		return
	monedas -= precio_liebre
	liebres += 1
	_refrescar_hud()
	ui.mostrar_mensaje("Compras una ración de liebre (-%d monedas)." % precio_liebre)

# ───────────────────────── Gatos y trampas ─────────────────────────
func _capturar_gato(gato) -> void:
	if randf() > gato.prob_captura_manual:
		gato.asustar(player.global_position)
		ui.mostrar_mensaje("¡El gato se te escapa! Las trampas son más fiables.")
		return
	gato.capturar()
	_ganar_gato(gato.raciones)

func _recoger_trampa(trampa) -> void:
	if not trampa.llena:
		ui.mostrar_mensaje("La trampa está vacía. Espera a que caiga un gato.")
		return
	_ganar_gato(trampa.recoger())

func _on_gato_atrapado(_trampa) -> void:
	ui.mostrar_mensaje("¡Una trampa del callejón ha atrapado un gato!")

func _ganar_gato(raciones: int) -> void:
	gatos += raciones
	var mult := 1.0
	if is_instance_valid(tavern.pizarra):
		mult = tavern.pizarra.multiplicador_captura()
	sospecha = minf(100.0, sospecha + sospecha_por_captura * mult)
	_refrescar_hud()
	ui.mostrar_mensaje("Carne de gato conseguida: +%d raciones." % raciones)
	if sospecha >= 100.0:
		_terminar("¡DESCUBIERTO!", "Los vecinos han visto demasiados gatos desaparecer.")

# ───────────────────────── Clientes ─────────────────────────
func _servir_cliente(cliente) -> void:
	if cliente.atendido:
		return
	var olla = _olla_con_guiso()
	if olla == null:
		ui.mostrar_mensaje("No hay guiso listo (o la olla está bloqueada).")
		return
	var impacto: float = cliente.impacto_sospecha(olla.sospecha_acumulada, sospecha_por_exceso)
	olla.servir_racion()
	cliente.atender(impacto)
	monedas += precio_racion
	sospecha = minf(100.0, sospecha + impacto)
	_refrescar_hud()
	if sospecha >= 100.0:
		_terminar("¡DESCUBIERTO!", "La taberna entera sabe lo que hay en tu guiso. Te echan a palos.")
		return
	if tavern.todos_atendidos():
		_nuevo_servicio()

func _nuevo_servicio() -> void:
	dia += 1
	sospecha = maxf(0.0, sospecha - bajada_sospecha_servicio)
	tavern.reiniciar_dia()
	_refrescar_hud()
	ui.mostrar_mensaje("Servicio completado. Entran clientes nuevos (día %d)." % dia, 4.0)

# ───────────────────────── Cobrador de la Mafia ─────────────────────────
func _actualizar_cobrador(delta: float) -> void:
	if tavern.cobrador.presente:
		paciencia_restante -= delta
		ui.actualizar_cobro("¡COBRADOR EN LA PUERTA! (%d s)" % int(ceil(maxf(0.0, paciencia_restante))))
		if paciencia_restante <= 0.0:
			_cobrador_pierde_paciencia()
	else:
		tiempo_restante -= delta
		ui.actualizar_cobro("Cobrador en: %d s" % int(ceil(maxf(0.0, tiempo_restante))))
		if tiempo_restante <= 0.0:
			_llega_cobrador()

func _llega_cobrador() -> void:
	interes_ultima_visita = deuda * interes_por_visita
	deuda += interes_ultima_visita
	paciencia_restante = paciencia_cobrador
	tavern.cobrador.aparecer()
	_refrescar_hud()
	ui.mostrar_mensaje("¡El cobrador de la mafia está en la puerta! (+%d de interés)" % int(round(interes_ultima_visita)), 5.0)
	if deuda >= deuda_limite:
		_terminar("LA MAFIA CUMPLE", "La deuda superó las %d monedas. Te quedas sin taberna." % int(deuda_limite))

func _cobrador_pierde_paciencia() -> void:
	deuda += penalizacion_deuda
	ui.mostrar_mensaje("El cobrador se cansa de esperar: +%d de deuda." % int(penalizacion_deuda), 4.0)
	_cobrador_se_va()
	if deuda >= deuda_limite:
		_terminar("LA MAFIA CUMPLE", "La deuda superó las %d monedas. Te quedas sin taberna." % int(deuda_limite))

func _cobrador_se_va() -> void:
	tavern.cobrador.ocultar()
	tiempo_restante = tiempo_deuda
	_cerrar_menus()
	_refrescar_hud()

func _abrir_cobrador() -> void:
	if not tavern.cobrador.presente:
		return
	_abrir_menu()
	ui.abrir_cobrador(deuda, int(ceil(minf(cuota_pago, deuda))), _olla_con_guiso() != null)

func _on_pagar() -> void:
	var pago := int(ceil(minf(cuota_pago, deuda)))
	if monedas < pago:
		ui.mostrar_mensaje("No tienes $%d para pagar." % pago)
		return
	monedas -= pago
	deuda -= pago
	if deuda <= 0.0:
		deuda = 0.0
		_refrescar_hud()
		_terminar("¡LIBRE!", "Saldaste la deuda con la mafia en el día %d. Y nadie lo sospecha." % dia)
		return
	_cobrador_se_va()
	ui.mostrar_mensaje("Pagas $%d. El cobrador se marcha... por ahora." % pago)

func _on_entregar() -> void:
	var olla = _olla_con_guiso()
	if olla == null:
		ui.mostrar_mensaje("No tienes guiso listo para entregar.")
		return
	var con_gato: bool = olla.pct_gato > 0.0
	olla.servir_racion()
	if con_gato:
		deuda += penalizacion_deuda
		olla.bloquear(bloqueo_olla_segundos)
		_cobrador_se_va()
		ui.mostrar_mensaje("¡Sabe a gato! +%d de deuda y la olla queda bloqueada %d s." % [int(penalizacion_deuda), int(bloqueo_olla_segundos)], 5.0)
		if deuda >= deuda_limite:
			_terminar("LA MAFIA CUMPLE", "La deuda superó las %d monedas. Te quedas sin taberna." % int(deuda_limite))
	else:
		deuda = maxf(0.0, deuda - interes_ultima_visita)
		_cobrador_se_va()
		ui.mostrar_mensaje("Guiso de liebre: el cobrador se relame y te perdona el interés de esta visita.", 5.0)

# ───────────────────────── Mejoras ─────────────────────────
func _abrir_mejoras() -> void:
	_abrir_menu()
	ui.abrir_mejoras(tavern.pizarra.estado(), monedas)

func _on_mejora_solicitada(id: String) -> void:
	var p = tavern.pizarra
	if p.ya_comprada(id):
		ui.mostrar_mensaje("Esa mejora ya está comprada.")
		return
	var coste: int = p.precio(id)
	if monedas < coste:
		ui.mostrar_mensaje("No tienes monedas suficientes.")
		return
	monedas -= coste
	p.aplicar(id)
	_refrescar_hud()
	ui.abrir_mejoras(p.estado(), monedas)
	if id == "olla_doble":
		ui.mostrar_mensaje("¡Segunda olla instalada en el mostrador!")
	else:
		ui.mostrar_mensaje("Cortinas puestas: cazar gatos levanta menos sospechas.")

# ───────────────────────── Fin de partida y HUD ─────────────────────────
func _terminar(titulo: String, texto: String) -> void:
	terminado = true
	player.set_controles(false)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	ui.mostrar_fin(titulo, texto)

func _reiniciar() -> void:
	get_tree().reload_current_scene()

func _refrescar_hud() -> void:
	ui.actualizar_hud({
		"dia": dia, "monedas": monedas, "deuda": deuda, "deuda_max": deuda_limite,
		"sospecha": sospecha, "gatos": gatos, "liebres": liebres,
		"especia": especia_nombre if especia_nombre != "" else "ninguna"
	})
