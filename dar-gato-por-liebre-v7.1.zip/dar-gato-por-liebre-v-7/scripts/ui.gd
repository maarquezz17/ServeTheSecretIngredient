extends CanvasLayer

signal cocinar_solicitado(proporcion_gato: float)
signal cocina_cerrada
signal pagar_solicitado
signal entregar_solicitado
signal cobrador_cerrado
signal mejora_solicitada(id: String)
signal mejoras_cerradas
signal reinicio_solicitado

@onready var label_dia: Label = $PanelEstado/VBox/LabelDia
@onready var label_monedas: Label = $PanelEstado/VBox/LabelMonedas
@onready var label_deuda: Label = $PanelEstado/VBox/LabelDeuda
@onready var barra_deuda: ProgressBar = $PanelEstado/VBox/BarraDeuda
@onready var label_sospecha: Label = $PanelEstado/VBox/LabelSospecha
@onready var barra_sospecha: ProgressBar = $PanelEstado/VBox/BarraSospecha
@onready var label_inventario: Label = $PanelEstado/VBox/LabelInventario
@onready var label_especia: Label = $PanelEstado/VBox/LabelEspecia
@onready var label_cobro: Label = $PanelEstado/VBox/LabelCobro
@onready var label_prompt: Label = $LabelPrompt
@onready var label_mensaje: Label = $LabelMensaje
@onready var timer_mensaje: Timer = $TimerMensaje

@onready var panel_cocina: PanelContainer = $PanelCocina
@onready var label_mix: Label = $PanelCocina/VBox/LabelMix
@onready var label_inv_cocina: Label = $PanelCocina/VBox/LabelInvCocina
@onready var slider_mix: HSlider = $PanelCocina/VBox/SliderMix
@onready var boton_cocinar: Button = $PanelCocina/VBox/BotonCocinar
@onready var boton_cerrar: Button = $PanelCocina/VBox/BotonCerrar

@onready var panel_cobrador: PanelContainer = $PanelCobrador
@onready var label_cobrador_texto: Label = $PanelCobrador/VBox/LabelCobradorTexto
@onready var boton_pagar: Button = $PanelCobrador/VBox/BotonPagar
@onready var boton_entregar: Button = $PanelCobrador/VBox/BotonEntregar
@onready var boton_cobrador_cerrar: Button = $PanelCobrador/VBox/BotonCobradorCerrar

@onready var panel_mejoras: PanelContainer = $PanelMejoras
@onready var label_mejoras_monedas: Label = $PanelMejoras/VBox/LabelMejorasMonedas
@onready var boton_olla_doble: Button = $PanelMejoras/VBox/BotonOllaDoble
@onready var boton_cortinas: Button = $PanelMejoras/VBox/BotonCortinas
@onready var boton_mejoras_cerrar: Button = $PanelMejoras/VBox/BotonMejorasCerrar

@onready var panel_fin: PanelContainer = $PanelFin
@onready var label_fin_titulo: Label = $PanelFin/VBox/LabelFinTitulo
@onready var label_fin_texto: Label = $PanelFin/VBox/LabelFinTexto
@onready var boton_reiniciar: Button = $PanelFin/VBox/BotonReiniciar

var _raciones_guiso := 4

func _ready() -> void:
	panel_cocina.visible = false
	panel_cobrador.visible = false
	panel_mejoras.visible = false
	panel_fin.visible = false
	label_mensaje.text = ""
	label_prompt.text = ""
	slider_mix.value_changed.connect(_on_slider)
	boton_cocinar.pressed.connect(func(): cocinar_solicitado.emit(slider_mix.value / 100.0))
	boton_cerrar.pressed.connect(func(): cocina_cerrada.emit())
	boton_pagar.pressed.connect(func(): pagar_solicitado.emit())
	boton_entregar.pressed.connect(func(): entregar_solicitado.emit())
	boton_cobrador_cerrar.pressed.connect(func(): cobrador_cerrado.emit())
	boton_olla_doble.pressed.connect(func(): mejora_solicitada.emit("olla_doble"))
	boton_cortinas.pressed.connect(func(): mejora_solicitada.emit("cortinas"))
	boton_mejoras_cerrar.pressed.connect(func(): mejoras_cerradas.emit())
	boton_reiniciar.pressed.connect(func(): reinicio_solicitado.emit())
	timer_mensaje.timeout.connect(func(): label_mensaje.text = "")

func actualizar_hud(d: Dictionary) -> void:
	label_dia.text = "DÍA %d" % d["dia"]
	label_monedas.text = "Monedas: %d" % int(d["monedas"])
	label_deuda.text = "Deuda de la Mafia: %d" % int(ceil(d["deuda"]))
	barra_deuda.max_value = d["deuda_max"]
	barra_deuda.value = d["deuda"]
	label_sospecha.text = "Suspicacia: %d%%" % int(d["sospecha"])
	barra_sospecha.value = d["sospecha"]
	label_inventario.text = "Gatos: %d   Liebres: %d" % [d["gatos"], d["liebres"]]
	label_especia.text = "Especia en mano: %s" % d["especia"]

func actualizar_cobro(texto: String) -> void:
	label_cobro.text = texto

func mostrar_prompt(texto: String) -> void:
	label_prompt.text = texto

func mostrar_mensaje(texto: String, segundos: float = 3.5) -> void:
	label_mensaje.text = texto
	timer_mensaje.start(segundos)

func hay_menu_abierto() -> bool:
	return panel_cocina.visible or panel_cobrador.visible or panel_mejoras.visible

func cerrar_todos() -> void:
	panel_cocina.visible = false
	panel_cobrador.visible = false
	panel_mejoras.visible = false

func abrir_cocina(gatos: int, liebres: int, raciones: int) -> void:
	cerrar_todos()
	_raciones_guiso = raciones
	label_inv_cocina.text = "Tienes %d raciones de gato y %d de liebre" % [gatos, liebres]
	panel_cocina.visible = true
	_on_slider(slider_mix.value)

func abrir_cobrador(deuda: float, pago: int, hay_guiso: bool) -> void:
	cerrar_todos()
	label_cobrador_texto.text = "«Debes %d monedas a la Mafia.\nO pagas, o nos das de comer.»" % int(ceil(deuda))
	boton_pagar.text = "Pagar $%d" % pago
	boton_entregar.disabled = not hay_guiso
	boton_entregar.text = "Entregar Guiso" if hay_guiso else "Entregar Guiso (no tienes guiso listo)"
	panel_cobrador.visible = true

func abrir_mejoras(d: Dictionary, monedas: int) -> void:
	cerrar_todos()
	label_mejoras_monedas.text = "Monedas: %d" % monedas
	if d["olla_doble"]:
		boton_olla_doble.text = "Olla Doble (comprada)"
	else:
		boton_olla_doble.text = "Olla Doble: cocina 2 platos a la vez ($%d)" % d["precio_olla_doble"]
	boton_olla_doble.disabled = d["olla_doble"] or monedas < d["precio_olla_doble"]
	if d["cortinas"]:
		boton_cortinas.text = "Cortinas del Callejón (compradas)"
	else:
		boton_cortinas.text = "Cortinas del Callejón: menos sospecha al cazar ($%d)" % d["precio_cortinas"]
	boton_cortinas.disabled = d["cortinas"] or monedas < d["precio_cortinas"]
	panel_mejoras.visible = true

func mostrar_fin(titulo: String, texto: String) -> void:
	cerrar_todos()
	label_fin_titulo.text = titulo
	label_fin_texto.text = texto
	panel_fin.visible = true

func _on_slider(valor: float) -> void:
	var g := int(round(valor / 100.0 * _raciones_guiso))
	label_mix.text = "Gato %d%% (%d)   /   Liebre %d%% (%d)" % [int(valor), g, 100 - int(valor), _raciones_guiso - g]
