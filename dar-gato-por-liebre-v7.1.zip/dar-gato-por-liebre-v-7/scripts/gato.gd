extends "res://scripts/interactuable.gd"
# Gato NPC: vaga por el callejón, huye si lo asustas y se siente atraído por las trampas vacías.
# Está en un AnimatableBody3D (hereda de StaticBody3D) para que pueda moverse y ser detectado por Area3D.

@export var raciones: int = 2
@export var velocidad: float = 0.6
@export var velocidad_huida: float = 3.0
@export var radio_vagabundeo: float = 3.0
@export var radio_olfato: float = 3.0
@export var radio_huida: float = 2.0
@export_range(0.0, 1.0, 0.05) var prob_atraccion_trampa: float = 0.2
@export_range(0.0, 1.0, 0.05) var prob_captura_manual: float = 0.4

var capturado := false

var _origen := Vector3.ZERO
var _destino := Vector3.ZERO
var _espera := 0.0
var _huida := 0.0

@onready var colision: CollisionShape3D = $Colision

func _ready() -> void:
	super()
	# Movemos el gato por script: sin sincronía con la física, su colisión sigue al nodo.
	set("sync_to_physics", false)
	tipo = "gato"
	add_to_group("gatos")
	_origen = global_position
	_destino = global_position
	_espera = randf_range(0.5, 2.0)

func get_prompt() -> String:
	return "E: Atrapar gato (se escapa a menudo; las trampas son más seguras)"

func _physics_process(delta: float) -> void:
	if capturado:
		return
	if _huida > 0.0:
		_huida -= delta
		_mover(delta, velocidad_huida)
		return
	var jugador = get_tree().get_first_node_in_group("jugador")
	if jugador != null and global_position.distance_to(jugador.global_position) < radio_huida:
		asustar(jugador.global_position)
		return
	if _espera > 0.0:
		_espera -= delta
		return
	if _distancia_plana(global_position, _destino) < 0.1:
		_espera = randf_range(2.0, 5.0)
		_elegir_destino()
		return
	_mover(delta, velocidad)

func asustar(desde: Vector3) -> void:
	var lejos := global_position - desde
	lejos.y = 0.0
	if lejos.length() < 0.01:
		lejos = Vector3(1.0, 0.0, 0.0)
	_destino = _limitar(global_position + lejos.normalized() * 3.0)
	_huida = 1.5

func capturar() -> void:
	capturado = true
	visible = false
	colision.set_deferred("disabled", true)

func reaparecer() -> void:
	capturado = false
	visible = true
	global_position = _origen
	_destino = _origen
	_huida = 0.0
	colision.set_deferred("disabled", false)

func _elegir_destino() -> void:
	if randf() < prob_atraccion_trampa:
		var mejor = null
		var mejor_d := radio_olfato
		for t in get_tree().get_nodes_in_group("trampas"):
			if t.llena:
				continue
			var d := _distancia_plana(global_position, t.global_position)
			if d < mejor_d:
				mejor_d = d
				mejor = t
		if mejor != null:
			_destino = Vector3(mejor.global_position.x, global_position.y, mejor.global_position.z)
			return
	_destino = _limitar(_origen + Vector3(randf_range(-radio_vagabundeo, radio_vagabundeo), 0.0, randf_range(-radio_vagabundeo, radio_vagabundeo)))

func _limitar(p: Vector3) -> Vector3:
	var d := p - _origen
	d.y = 0.0
	if d.length() > radio_vagabundeo:
		d = d.normalized() * radio_vagabundeo
	return Vector3(_origen.x + d.x, global_position.y, _origen.z + d.z)

func _mover(delta: float, vel: float) -> void:
	var dir := _destino - global_position
	dir.y = 0.0
	if dir.length() < 0.05:
		return
	dir = dir.normalized()
	global_position += dir * vel * delta
	rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), 8.0 * delta)

func _distancia_plana(a: Vector3, b: Vector3) -> float:
	return Vector2(a.x - b.x, a.z - b.z).length()
