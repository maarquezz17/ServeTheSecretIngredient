extends "res://scripts/interactuable.gd"
# Frasco del estante de especias. Se coge con E (cuesta monedas) y se echa en una olla con guiso.

@export var nombre: String = "Romero"
@export_range(0.0, 1.0, 0.05) var reduccion: float = 0.2
@export var precio: int = 3

func _ready() -> void:
	super()
	tipo = "especia"

func get_prompt() -> String:
	return "E: Coger %s (%d monedas, -%d%% sospecha del guiso)" % [nombre, precio, int(round(reduccion * 100.0))]
