extends "res://scripts/interactuable.gd"

enum TipoCliente { NORMAL, BORRACHO, INSPECTOR }

# Proporción de sospecha del guiso que su paladar tolera (0.0 - 1.0).
@export_range(0.0, 1.0, 0.05) var tolerancia: float = 0.3
@export_range(0.0, 1.0, 0.05) var prob_borracho: float = 0.2
@export_range(0.0, 1.0, 0.05) var prob_inspector: float = 0.2
@export var multiplicador_inspector: float = 3.0
# Para probar un tipo concreto desde el Inspector sin depender del azar.
@export var forzar_tipo: bool = false
@export var tipo_forzado: TipoCliente = TipoCliente.NORMAL

var tipo_cliente: TipoCliente = TipoCliente.NORMAL
var atendido := false

@onready var burbuja: Label3D = $Burbuja
@onready var sombrero: MeshInstance3D = $Sombrero

func _ready() -> void:
	super()
	tipo = "cliente"
	add_to_group("clientes")
	reiniciar()

func get_prompt() -> String:
	if atendido:
		return "Este cliente ya ha comido"
	return "E: Servir guiso"

# Se llama al aparecer cada cliente (inicio y cada nuevo servicio): asigna el tipo al azar.
func reiniciar() -> void:
	atendido = false
	if forzar_tipo:
		tipo_cliente = tipo_forzado
	else:
		var r := randf()
		if r < prob_inspector:
			tipo_cliente = TipoCliente.INSPECTOR
		elif r < prob_inspector + prob_borracho:
			tipo_cliente = TipoCliente.BORRACHO
		else:
			tipo_cliente = TipoCliente.NORMAL
	sombrero.visible = tipo_cliente == TipoCliente.INSPECTOR
	match tipo_cliente:
		TipoCliente.INSPECTOR:
			burbuja.text = "¡Hambre!"
		TipoCliente.BORRACHO:
			burbuja.text = "¡Hic! ¡Hambre!"
		_:
			burbuja.text = "¡Hambre! (paladar %s)" % _paladar()

# Cuánta suspicacia (en puntos de la barra) provoca servirle un guiso con esa sospecha acumulada.
func impacto_sospecha(sospecha_guiso: float, factor: float) -> float:
	match tipo_cliente:
		TipoCliente.BORRACHO:
			return 0.0
		TipoCliente.INSPECTOR:
			return maxf(0.0, sospecha_guiso - tolerancia) * factor * multiplicador_inspector
		_:
			return maxf(0.0, sospecha_guiso - tolerancia) * factor

func atender(impacto: float) -> void:
	atendido = true
	if tipo_cliente == TipoCliente.BORRACHO:
		burbuja.text = "¡Hic! ¡Qué rico!"
	elif impacto > 0.0 and tipo_cliente == TipoCliente.INSPECTOR:
		burbuja.text = "Mmm... esto me huele a gato. Lo anotaré."
	elif impacto > 0.0:
		burbuja.text = "Hmm... ¿esto sabe a gato?"
	else:
		burbuja.text = "¡Delicioso!"

func _paladar() -> String:
	if tolerancia < 0.3:
		return "fino"
	if tolerancia >= 0.5:
		return "poco fino"
	return "normal"
