# Dar Gato Por Liebre — v7 (Godot 4.7.2)

Abre `project.godot` y pulsa F5. Tu `Main.tscn` y tu `project.godot` se han respetado tal cual;
todo lo nuevo vive en `Tavern.tscn`, `UI.tscn` y los scripts. Al abrir `Main.tscn` verás todo
(Editable Children activo) y también puedes editarlo abriendo `Tavern.tscn`.

## Qué hay nuevo y dónde está (todo son nodos del .tscn, sin crear nada por código)
| Elemento | Nodo en Tavern.tscn | Script |
|---|---|---|
| Puerta principal (pared frontal, opuesta al mostrador) | Estructura/PuertaPrincipal (MeshInstance3D BoxMesh + Marco + Manija) | — |
| Logo | Cocina/Logo/Imagen (Sprite3D, assets/logo.png) sobre Cocina/Logo/Placa | — |
| Trampas | Callejon/Trampas/TrampaA,B,C (StaticBody3D + Caja + Area3D "Zona") | trampa.gd |
| Estante de especias | Cocina/EstanteEspecias (Mueble + FrascoRomero/Pimienta/Vino) | especia.gd |
| Segunda olla | Cocina/Olla2 (sobre el mostrador) | olla.gd |
| Pizarra de mejoras | Cocina/Pizarra | mejoras.gd |
| Cortinas | Callejon/Cortinas | — |
| Sombrero del inspector | Comedor/ClienteN/Sombrero | cliente.gd |
| Cobrador de la Mafia | Mafia/Cobrador (CharacterBody3D) | cobrador.gd |

Los elementos que arrancan ocultos en partida (Olla2, Cortinas, Cobrador, sombreros de no-inspectores)
SÍ se ven en el editor para que puedas moverlos y cambiarles el material; el script los oculta al ejecutar.

## Cómo se juega
WASD mover · ratón mirar · E interactuar · Esc cerrar menú.
- Gatos: vagan por el callejón. Puedes atraparlos a mano (a menudo se escapan) o esperar a que caigan en una trampa y recogerla.
- Especias: cógelas del estante (cuestan monedas) y úsalas sobre una olla CON guiso: bajan su sospecha_acumulada.
- Clientes (tipo al azar cada servicio): NORMAL; BORRACHO (impacto 0); INSPECTOR (sombrero, impacto x3).
- Cobrador: cuando llega a cero `tiempo_deuda` aparece ante la puerta. Interactúa: "Pagar $X" o "Entregar Guiso"
  (liebre pura = te perdona el interés de la visita; con gato = +deuda y olla bloqueada 30 s).
  Si lo ignoras `paciencia_cobrador` segundos, se va y te sube la deuda.
- Pizarra: Olla Doble (cocinar dos platos a la vez) y Cortinas (menos sospecha al cazar).
Ganas saldando la deuda; pierdes con 100 % de suspicacia o si la deuda llega a `deuda_limite`.

## Ajustes sin tocar código
- Nodo `Main` (Inspector): tiempo_deuda, cuota_pago, interés, penalizaciones, precios, etc.
- Cada cliente: tolerancia, probabilidades de tipo, o "Forzar Tipo" para probar un tipo concreto.
- Cada frasco: nombre, reducción y precio. Cada gato: velocidad, probabilidad de captura manual... Cada trampa: color_llena.
- Pizarra: precios y multiplicador de las cortinas.

## Logo
`assets/logo.png` es tu diseño de luna con flores (fondo transparente, línea oscura). Para cambiarlo,
sustituye ese archivo manteniendo el nombre; la placa crema de detrás es el nodo Cocina/Logo/Placa.

Nombres que los scripts esperan: Cocina/Olla, Cocina/Olla2, Cocina/Pizarra, Callejon/Cortinas, Mafia/Cobrador y Luces.
