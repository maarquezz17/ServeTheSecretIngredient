extends Node
# Singleton (Autoload "SaveSystem"): guardado de partida y ajustes del jugador.
#  - Partida: user://savegame.json (día, monedas, deuda, suspicacia, hora, inventario).
#  - Ajustes: user://settings.json (volumen, sensibilidad del ratón y teclas reasignadas).
#    Son globales: se cargan al arrancar el juego, valen para cualquier partida y no dependen de que exista un guardado.
# Flujo de carga: el menú llama a preparar_carga() y cambia a Main.tscn; game.gd recoge los datos con consumir_pendientes().

const RUTA_GUARDADO := "user://savegame.json"
const RUTA_AJUSTES := "user://settings.json"
const VERSION := 1

# Acciones cuyas teclas se pueden reasignar desde Ajustes, con el nombre que se muestra al jugador.
const ACCIONES_REASIGNABLES := {
	"interact": "Interactuar",
	"drop_item": "Soltar",
	"inventario": "Inventario"
}
const TECLAS_POR_DEFECTO := {
	"interact": KEY_E,
	"drop_item": KEY_F,
	"inventario": KEY_Q
}
# Resto de acciones: no se reasignan, pero sus teclas cuentan para detectar conflictos.
const ACCIONES_FIJAS := {
	"move_forward": "Avanzar",
	"move_backward": "Retroceder",
	"move_left": "Izquierda",
	"move_right": "Derecha"
}
const SENSIBILIDAD_MIN := 0.25
const SENSIBILIDAD_MAX := 3.0

# Datos leídos del archivo que game.gd aplicará al arrancar (vacío = partida nueva).
var datos_pendientes: Dictionary = {}

# Ajustes del jugador
var volumen_master: float = 1.0        # 0.0 - 1.0 (lineal) sobre el bus Master
var sensibilidad_raton: float = 1.0    # multiplicador del movimiento del ratón (player.gd)
var teclas: Dictionary = {}            # acción -> physical_keycode (solo las reasignadas)

func _ready() -> void:
	cargar_ajustes()
	aplicar_ajustes()

# Convierte un texto JSON en Dictionary. Devuelve {} si no es un objeto JSON válido.
func _parsear_objeto(texto: String) -> Dictionary:
	var limpio := texto.strip_edges()
	if not (limpio.begins_with("{") and limpio.ends_with("}")):
		return {}
	var contenido = JSON.parse_string(limpio)
	if typeof(contenido) != TYPE_DICTIONARY:
		return {}
	return contenido

# ───────────────────────── Partida ─────────────────────────
func existe_partida() -> bool:
	return FileAccess.file_exists(RUTA_GUARDADO)

# Escribe la partida. Devuelve true si se guardó correctamente.
func guardar(datos: Dictionary) -> bool:
	var archivo := FileAccess.open(RUTA_GUARDADO, FileAccess.WRITE)
	if archivo == null:
		push_warning("SaveSystem: no se pudo abrir %s (error %d)" % [RUTA_GUARDADO, FileAccess.get_open_error()])
		return false
	var paquete: Dictionary = datos.duplicate(true)
	paquete["version"] = VERSION
	archivo.store_string(JSON.stringify(paquete, "\t"))
	archivo.close()
	return true

# Lee y valida el archivo. Devuelve {} si no existe o está corrupto.
func leer() -> Dictionary:
	if not existe_partida():
		return {}
	var archivo := FileAccess.open(RUTA_GUARDADO, FileAccess.READ)
	if archivo == null:
		push_warning("SaveSystem: no se pudo leer %s (error %d)" % [RUTA_GUARDADO, FileAccess.get_open_error()])
		return {}
	var texto := archivo.get_as_text()
	archivo.close()
	var datos := _parsear_objeto(texto)
	if datos.is_empty():
		push_warning("SaveSystem: el archivo de guardado está dañado.")
		return {}
	if not datos.has("dia") or not datos.has("monedas") or not datos.has("deuda"):
		push_warning("SaveSystem: el archivo de guardado está incompleto.")
		return {}
	return datos

# Prepara la carga de la partida guardada. Devuelve false si no hay una partida válida.
func preparar_carga() -> bool:
	var datos := leer()
	if datos.is_empty():
		datos_pendientes = {}
		return false
	datos_pendientes = datos
	return true

func nueva_partida() -> void:
	datos_pendientes = {}

# game.gd llama a esto una sola vez al arrancar: devuelve los datos cargados y los descarta.
func consumir_pendientes() -> Dictionary:
	var datos := datos_pendientes
	datos_pendientes = {}
	return datos

func borrar_partida() -> void:
	if existe_partida():
		DirAccess.remove_absolute(ProjectSettings.globalize_path(RUTA_GUARDADO))

# ───────────────────────── Ajustes: volumen y sensibilidad ─────────────────────────
func set_volumen(valor: float) -> void:
	volumen_master = clampf(valor, 0.0, 1.0)
	_aplicar_volumen()

func set_sensibilidad(valor: float) -> void:
	sensibilidad_raton = clampf(valor, SENSIBILIDAD_MIN, SENSIBILIDAD_MAX)

func _aplicar_volumen() -> void:
	var bus := AudioServer.get_bus_index("Master")
	AudioServer.set_bus_volume_db(bus, linear_to_db(maxf(volumen_master, 0.0001)))
	AudioServer.set_bus_mute(bus, volumen_master <= 0.001)

# ───────────────────────── Ajustes: teclas ─────────────────────────
# Devuelve el physical_keycode actual de una acción (0 si no tiene tecla).
func codigo_tecla(accion: String) -> int:
	for evento in InputMap.action_get_events(accion):
		if evento is InputEventKey:
			return evento.physical_keycode if evento.physical_keycode != 0 else evento.keycode
	return 0

# Texto legible de la tecla de una acción (respeta la distribución del teclado del jugador).
func nombre_tecla(accion: String) -> String:
	var codigo := codigo_tecla(accion)
	if codigo == 0:
		return "—"
	var etiqueta: int = codigo
	# Solo Windows, Linux y macOS saben traducir la tecla física a la letra de la distribución del teclado.
	if DisplayServer.get_name() != "headless" and (OS.has_feature("windows") or OS.has_feature("linuxbsd") or OS.has_feature("macos")):
		var traducida: int = DisplayServer.keyboard_get_label_from_physical(codigo)
		if traducida != 0:
			etiqueta = traducida
	return OS.get_keycode_string(etiqueta)

# Reasigna una acción a la tecla del evento. Devuelve "" si todo fue bien o un mensaje de error.
# (InputMap.action_change_event() no existe en Godot 4: se usa action_erase_events() + action_add_event().)
func reasignar_accion(accion: String, evento: InputEventKey) -> String:
	if not ACCIONES_REASIGNABLES.has(accion):
		return "Esa acción no se puede reasignar."
	var codigo: int = evento.physical_keycode if evento.physical_keycode != 0 else evento.keycode
	if codigo == 0 or codigo == KEY_ESCAPE:
		return "Tecla no válida."
	var ocupada := _accion_que_usa(codigo, accion)
	if ocupada != "":
		return "Esa tecla ya la usa «%s»." % ocupada
	if not _poner_tecla(accion, codigo):
		return "No se pudo asignar la tecla."
	teclas[accion] = codigo
	guardar_ajustes()
	return ""

func restablecer_controles() -> void:
	for accion in TECLAS_POR_DEFECTO.keys():
		_poner_tecla(accion, TECLAS_POR_DEFECTO[accion])
	teclas.clear()
	guardar_ajustes()

# Nombre de la acción (distinta de "excepto") que ya usa ese código de tecla, o "" si está libre.
func _accion_que_usa(codigo: int, excepto: String) -> String:
	var todas: Dictionary = ACCIONES_REASIGNABLES.duplicate()
	todas.merge(ACCIONES_FIJAS)
	for accion in todas.keys():
		if accion == excepto:
			continue
		for evento in InputMap.action_get_events(accion):
			if evento is InputEventKey:
				if evento.physical_keycode == codigo or (evento.physical_keycode == 0 and evento.keycode == codigo):
					return todas[accion]
	return ""

# Sustituye el evento de teclado de la acción por uno equivalente con otra tecla.
func _poner_tecla(accion: String, codigo: int) -> bool:
	var base: InputEventKey = null
	for evento in InputMap.action_get_events(accion):
		if evento is InputEventKey:
			base = evento
			break
	if base == null:
		return false
	var nuevo := base.duplicate() as InputEventKey
	nuevo.keycode = 0
	nuevo.key_label = 0
	nuevo.unicode = 0
	nuevo.physical_keycode = codigo
	InputMap.action_erase_events(accion)
	InputMap.action_add_event(accion, nuevo)
	return true

# ───────────────────────── Ajustes: archivo ─────────────────────────
func guardar_ajustes() -> bool:
	var archivo := FileAccess.open(RUTA_AJUSTES, FileAccess.WRITE)
	if archivo == null:
		push_warning("SaveSystem: no se pudieron guardar los ajustes (error %d)" % FileAccess.get_open_error())
		return false
	var paquete := {
		"version": VERSION,
		"volumen": volumen_master,
		"sensibilidad": sensibilidad_raton,
		"teclas": teclas
	}
	archivo.store_string(JSON.stringify(paquete, "\t"))
	archivo.close()
	return true

# Lee user://settings.json. Si falta o está dañado se mantienen los valores por defecto.
func cargar_ajustes() -> void:
	if not FileAccess.file_exists(RUTA_AJUSTES):
		return
	var texto := FileAccess.get_file_as_string(RUTA_AJUSTES)
	var datos := _parsear_objeto(texto)
	if datos.is_empty():
		push_warning("SaveSystem: el archivo de ajustes está dañado; se usan los valores por defecto.")
		return
	volumen_master = clampf(float(datos.get("volumen", 1.0)), 0.0, 1.0)
	sensibilidad_raton = clampf(float(datos.get("sensibilidad", 1.0)), SENSIBILIDAD_MIN, SENSIBILIDAD_MAX)
	teclas.clear()
	var guardadas = datos.get("teclas", {})
	if typeof(guardadas) == TYPE_DICTIONARY:
		for accion in guardadas.keys():
			if ACCIONES_REASIGNABLES.has(accion) and int(guardadas[accion]) > 0:
				teclas[str(accion)] = int(guardadas[accion])

# Vuelca los ajustes al motor: volumen del bus Master y teclas reasignadas en el InputMap.
func aplicar_ajustes() -> void:
	_aplicar_volumen()
	for accion in teclas.keys():
		_poner_tecla(accion, int(teclas[accion]))
