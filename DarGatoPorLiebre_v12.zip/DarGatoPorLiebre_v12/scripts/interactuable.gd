extends StaticBody3D
# Base de todo objeto con el que el jugador puede interactuar (E).
# Editable desde el Inspector: "tipo", "prompt" y los parámetros del feedback visual.

signal interactuado(objeto)

@export var tipo: String = ""
@export var prompt: String = "E: Interactuar"
# Feedback al interactuar: el objeto "pega un botecito" (escala) y tiembla (giro) con Tweens.
@export var feedback_activo: bool = true
@export var feedback_escala: float = 1.08
@export var feedback_temblor: float = 0.05     # radianes

var _tween_escala: Tween = null
var _tween_temblor: Tween = null
var _escala_base := Vector3.ONE
var _rot_z_base := 0.0
var _feedback_en_curso := false

func _ready() -> void:
	add_to_group("interactuable")

func get_prompt() -> String:
	return prompt

func interactuar() -> void:
	_feedback()
	interactuado.emit(self)

func _feedback() -> void:
	if not feedback_activo or not is_inside_tree() or not visible:
		return
	# Si se interactúa de nuevo en mitad de la animación, se vuelve a la pose base antes de repetirla.
	if _feedback_en_curso:
		_detener_feedback()
		scale = _escala_base
		rotation.z = _rot_z_base
	else:
		_escala_base = scale
		_rot_z_base = rotation.z
	_feedback_en_curso = true
	_tween_escala = create_tween()
	_tween_escala.tween_property(self, "scale", _escala_base * feedback_escala, 0.07).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	_tween_escala.tween_property(self, "scale", _escala_base, 0.22).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_tween_escala.finished.connect(_on_feedback_terminado)
	_tween_temblor = create_tween()
	_tween_temblor.tween_property(self, "rotation:z", _rot_z_base + feedback_temblor, 0.04)
	_tween_temblor.tween_property(self, "rotation:z", _rot_z_base - feedback_temblor, 0.07)
	_tween_temblor.tween_property(self, "rotation:z", _rot_z_base + feedback_temblor * 0.5, 0.06)
	_tween_temblor.tween_property(self, "rotation:z", _rot_z_base, 0.05)

func _detener_feedback() -> void:
	if _tween_escala != null and _tween_escala.is_valid():
		_tween_escala.kill()
	if _tween_temblor != null and _tween_temblor.is_valid():
		_tween_temblor.kill()

func _on_feedback_terminado() -> void:
	_feedback_en_curso = false
