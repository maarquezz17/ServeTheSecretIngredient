extends Control
# Menú principal: fondo 3D de la taberna (declarado en MainMenu.tscn) + menú a la izquierda.

const ESCENA_JUEGO := "res://scenes/Main.tscn"

@onready var camara: Camera3D = $Fondo3D/Vista/Escena/Camara
@onready var luces: Node3D = $Fondo3D/Vista/Escena/Luces
@onready var boton_jugar: Button = $Botones/BotonJugar
@onready var boton_cargar: Button = $Botones/BotonCargar
@onready var boton_ajustes: Button = $Botones/BotonAjustes
@onready var boton_salir: Button = $Botones/BotonSalir
@onready var label_estado: Label = $LabelEstado
@onready var contenedor_botones: VBoxContainer = $Botones
@onready var ajustes: PanelContainer = $Ajustes

var _energia_base := {}
var _pos_camara_base := Vector3.ZERO
var _rot_camara_base := Vector3.ZERO
var _tiempo := 0.0

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().paused = false
	_pos_camara_base = camara.position
	_rot_camara_base = camara.rotation
	for l in luces.get_children():
		if l is OmniLight3D:
			_energia_base[l] = l.light_energy
	boton_jugar.pressed.connect(_on_jugar_pressed)
	boton_cargar.pressed.connect(_on_cargar_pressed)
	boton_ajustes.pressed.connect(_on_ajustes_pressed)
	boton_salir.pressed.connect(_on_salir_pressed)
	ajustes.cerrado.connect(_on_ajustes_cerrados)
	# Efecto extra al pasar el ratón (además del estilo "hover" del Theme): el botón crece y se ilumina.
	for b in [boton_jugar, boton_cargar, boton_ajustes, boton_salir]:
		b.mouse_entered.connect(_on_hover.bind(b, true))
		b.mouse_exited.connect(_on_hover.bind(b, false))
		b.focus_entered.connect(_on_hover.bind(b, true))
		b.focus_exited.connect(_on_hover.bind(b, false))
	_actualizar_estado_guardado()
	boton_jugar.grab_focus()

func _process(delta: float) -> void:
	_tiempo += delta
	# Velas y hogar: parpadeo de las luces ya declaradas en la escena.
	var i := 0
	for l in _energia_base.keys():
		var ritmo := 5.0 + float(i) * 1.3
		l.light_energy = _energia_base[l] * (1.0 + 0.10 * sin(_tiempo * ritmo + float(i) * 2.1) + 0.05 * sin(_tiempo * ritmo * 2.7))
		i += 1
	# Cámara: balanceo lento para dar vida al fondo.
	camara.position = _pos_camara_base + Vector3(sin(_tiempo * 0.23) * 0.22, sin(_tiempo * 0.31) * 0.05, cos(_tiempo * 0.17) * 0.12)
	camara.rotation = _rot_camara_base + Vector3(0.0, sin(_tiempo * 0.19) * 0.015, 0.0)

func _actualizar_estado_guardado() -> void:
	var hay := SaveSystem.existe_partida()
	boton_cargar.disabled = not hay
	label_estado.text = "" if hay else "No hay ninguna partida guardada."

func _on_hover(boton: Button, entra: bool) -> void:
	if boton.disabled:
		return
	boton.pivot_offset = Vector2(0.0, boton.size.y * 0.5)
	var t := create_tween().set_parallel(true)
	t.tween_property(boton, "scale", Vector2(1.06, 1.06) if entra else Vector2.ONE, 0.12).set_trans(Tween.TRANS_SINE)
	t.tween_property(boton, "modulate", Color(1.15, 1.05, 0.9, 1.0) if entra else Color.WHITE, 0.12)

func _on_jugar_pressed() -> void:
	SaveSystem.nueva_partida()
	get_tree().change_scene_to_file(ESCENA_JUEGO)

func _on_cargar_pressed() -> void:
	if SaveSystem.preparar_carga():
		get_tree().change_scene_to_file(ESCENA_JUEGO)
	else:
		_actualizar_estado_guardado()
		label_estado.text = "No se pudo leer la partida guardada."

# Ajustes: el panel (settings_menu.gd) sustituye temporalmente a los botones del menú.
func _on_ajustes_pressed() -> void:
	contenedor_botones.visible = false
	label_estado.visible = false
	ajustes.abrir()

func _on_ajustes_cerrados() -> void:
	contenedor_botones.visible = true
	label_estado.visible = true
	boton_ajustes.grab_focus()

func _on_salir_pressed() -> void:
	get_tree().quit()
