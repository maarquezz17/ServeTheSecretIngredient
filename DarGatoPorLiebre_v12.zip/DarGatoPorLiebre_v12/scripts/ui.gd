extends CanvasLayer

signal cocinar_solicitado(proporcion_gato: float)
signal cocina_cerrada
signal especia_solicitada(indice: int)
signal servir_olla_solicitado
signal pagar_solicitado
signal entregar_solicitado
signal cobrador_cerrado
signal mejora_solicitada(id: String)
signal mejoras_cerradas
signal reinicio_solicitado
signal menu_solicitado
signal pausa_continuar
signal guardar_solicitado

# HUD principal (esquina superior izquierda)
@onready var label_dia: Label = $HUD/PanelEstado/VBox/LabelDia
@onready var label_monedas: Label = $HUD/PanelEstado/VBox/LabelMonedas
@onready var label_deuda: Label = $HUD/PanelEstado/VBox/LabelDeuda
@onready var barra_deuda: ProgressBar = $HUD/PanelEstado/VBox/BarraDeuda
@onready var label_sospecha: Label = $HUD/PanelEstado/VBox/LabelSospecha
@onready var barra_sospecha: ProgressBar = $HUD/PanelEstado/VBox/BarraSospecha
@onready var label_cobro: Label = $HUD/PanelEstado/VBox/LabelCobro

# Reloj (esquina superior derecha)
@onready var label_reloj: Label = $LabelReloj

# Inventario (se muestra mientras se mantiene pulsada la tecla Q)
@onready var panel_inventario: PanelContainer = $PanelInventario
@onready var label_gatos_inv: Label = $PanelInventario/VBox/LabelGatosInv
@onready var label_liebres_inv: Label = $PanelInventario/VBox/LabelLiebresInv
@onready var label_especias_inv: Label = $PanelInventario/VBox/LabelEspeciasInv
@onready var label_fregona_inv: Label = $PanelInventario/VBox/LabelFregonaInv
@onready var label_manchas_inv: Label = $PanelInventario/VBox/LabelManchasInv

@onready var label_prompt: Label = $LabelPrompt
@onready var label_mensaje: Label = $LabelMensaje
@onready var timer_mensaje: Timer = $TimerMensaje

@onready var panel_cocina: PanelContainer = $PanelCocina
@onready var label_olla: Label = $PanelCocina/VBox/LabelOlla
@onready var label_mix: Label = $PanelCocina/VBox/LabelMix
@onready var label_mezcla: Label = $PanelCocina/VBox/LabelMezcla
@onready var boton_servir_olla: Button = $PanelCocina/VBox/BotonServirOlla
@onready var botones_especia: Array[Button] = [
	$PanelCocina/VBox/Especia1, $PanelCocina/VBox/Especia2, $PanelCocina/VBox/Especia3
]
@onready var label_inv_cocina: Label = $PanelCocina/VBox/LabelInvCocina
@onready var slider_mix: HSlider = $PanelCocina/VBox/SliderMix
@onready var boton_cocinar: Button = $PanelCocina/VBox/BotonCocinar
@onready var boton_cerrar: Button = $PanelCocina/VBox/BotonCerrar

@onready var panel_cobrador: PanelContainer = $PanelCobrador
@onready var label_cobrador_texto: Label = $PanelCobrador/VBox/LabelCobradorTexto
@onready var boton_pagar: Button = $PanelCobrador/VBox/BotonPagar
@onready var boton_entregar: Button = $PanelCobrador/VBox/BotonEntregar
@onready var boton_cobrador_cerrar: Button = $PanelCobrador/VBox/BotonCobradorCerrar

@onready var panel_mejoras: PanelContainer = $PanelMejoras
@onready var label_mejoras_monedas: Label = $PanelMejoras/VBox/LabelMejorasMonedas
@onready var boton_olla_doble: Button = $PanelMejoras/VBox/BotonOllaDoble
@onready var boton_cortinas: Button = $PanelMejoras/VBox/BotonCortinas
@onready var boton_mejoras_cerrar: Button = $PanelMejoras/VBox/BotonMejorasCerrar

@onready var panel_pausa: PanelContainer = $PanelPausa
@onready var boton_continuar: Button = $PanelPausa/VBox/BotonContinuar
@onready var boton_guardar: Button = $PanelPausa/VBox/BotonGuardar
@onready var boton_ajustes_pausa: Button = $PanelPausa/VBox/BotonAjustesPausa
@onready var boton_menu_pausa: Button = $PanelPausa/VBox/BotonMenuPausa
@onready var ajustes: PanelContainer = $Ajustes

@onready var panel_fin: PanelContainer = $PanelFin
@onready var label_fin_titulo: Label = $PanelFin/VBox/LabelFinTitulo
@onready var label_fin_texto: Label = $PanelFin/VBox/LabelFinTexto
@onready var boton_reiniciar: Button = $PanelFin/VBox/BotonReiniciar
@onready var boton_menu: Button = $PanelFin/VBox/BotonMenu

var _raciones_guiso := 4

func _ready() -> void:
	panel_cocina.visible = false
	panel_cobrador.visible = false
	panel_mejoras.visible = false
	panel_fin.visible = false
	panel_inventario.visible = false
	panel_pausa.visible = false
	label_mensaje.text = ""
	label_prompt.text = ""
	slider_mix.value_changed.connect(_on_slider)
	boton_cocinar.pressed.connect(func(): cocinar_solicitado.emit(slider_mix.value / 100.0))
	boton_cerrar.pressed.connect(func(): cocina_cerrada.emit())
	boton_servir_olla.pressed.connect(func(): servir_olla_solicitado.emit())
	for i in botones_especia.size():
		botones_especia[i].pressed.connect(func(): especia_solicitada.emit(i))
	boton_pagar.pressed.connect(func(): pagar_solicitado.emit())
	boton_entregar.pressed.connect(func(): entregar_solicitado.emit())
	boton_cobrador_cerrar.pressed.connect(func(): cobrador_cerrado.emit())
	boton_olla_doble.pressed.connect(func(): mejora_solicitada.emit("olla_doble"))
	boton_cortinas.pressed.connect(func(): mejora_solicitada.emit("cortinas"))
	boton_mejoras_cerrar.pressed.connect(func(): mejoras_cerradas.emit())
	boton_reiniciar.pressed.connect(func(): reinicio_solicitado.emit())
	boton_menu.pressed.connect(func(): menu_solicitado.emit())
	boton_continuar.pressed.connect(func(): pausa_continuar.emit())
	boton_guardar.pressed.connect(func(): guardar_solicitado.emit())
	boton_menu_pausa.pressed.connect(func(): menu_solicitado.emit())
	boton_ajustes_pausa.pressed.connect(_abrir_ajustes)
	ajustes.cerrado.connect(_on_ajustes_cerrados)
	timer_mensaje.timeout.connect(func(): label_mensaje.text = "")

# El inventario solo se ve mientras se mantiene pulsada Q (y no hay otro menú abierto).
func _process(_delta: float) -> void:
	panel_inventario.visible = Input.is_action_pressed("inventario") and not hay_menu_abierto() and not panel_fin.visible

func actualizar_hud(d: Dictionary) -> void:
	label_dia.text = "DÍA %d" % d["dia"]
	label_monedas.text = "Monedas: %d" % int(d["monedas"])
	label_deuda.text = "Deuda de la Mafia: %d" % int(ceil(d["deuda"]))
	barra_deuda.max_value = d["deuda_max"]
	barra_deuda.value = d["deuda"]
	label_sospecha.text = "Suspicacia: %d%%" % int(d["sospecha"])
	barra_sospecha.value = d["sospecha"]
	# Datos del inventario (panel oculto salvo con Q)
	label_gatos_inv.text = "Carne de gato: %d raciones" % d["gatos"]
	label_liebres_inv.text = "Liebre: %d raciones" % d["liebres"]
	label_especias_inv.text = "Especias:\n%s" % d["especias"]
	label_fregona_inv.text = "Fregona: %s" % ("equipada (F para soltar)" if d["fregona"] else "no la tienes")
	label_manchas_inv.text = "Manchas sin limpiar: %d" % d["manchas"]

func actualizar_cobro(texto: String) -> void:
	label_cobro.text = texto

func actualizar_hora(texto: String) -> void:
	label_reloj.text = texto

func mostrar_prompt(texto: String) -> void:
	label_prompt.text = texto

func mostrar_mensaje(texto: String, segundos: float = 3.5) -> void:
	label_mensaje.text = texto
	timer_mensaje.start(segundos)

func hay_menu_abierto() -> bool:
	return panel_cocina.visible or panel_cobrador.visible or panel_mejoras.visible or panel_pausa.visible or ajustes.visible

# Esta capa sigue procesando con el juego en pausa (process_mode = Always en UI.tscn),
# así que es ella quien cierra la pausa con Esc.
func _unhandled_input(event: InputEvent) -> void:
	if panel_pausa.visible and event.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		pausa_continuar.emit()

# Ajustes desde la pausa: sustituye al panel de pausa y, al cerrarse, lo devuelve.
func _abrir_ajustes() -> void:
	panel_pausa.visible = false
	ajustes.abrir()

func _on_ajustes_cerrados() -> void:
	panel_pausa.visible = true
	boton_continuar.grab_focus()

func abrir_pausa() -> void:
	cerrar_todos()
	panel_pausa.visible = true
	boton_continuar.grab_focus()

func cerrar_pausa() -> void:
	panel_pausa.visible = false

func cerrar_todos() -> void:
	panel_cocina.visible = false
	panel_cobrador.visible = false
	panel_mejoras.visible = false

func abrir_cocina(d: Dictionary) -> void:
	cerrar_todos()
	panel_cocina.visible = true
	actualizar_cocina(d)

# Refresca el menú de la olla sin cerrarlo (tras echar una especia, por ejemplo).
func actualizar_cocina(d: Dictionary) -> void:
	_raciones_guiso = d["raciones_guiso"]
	var vacia: bool = d["olla_vacia"]
	label_olla.text = d["estado_olla"]
	label_inv_cocina.text = "Tienes %d raciones de gato y %d de liebre" % [d["gatos"], d["liebres"]]
	boton_cocinar.disabled = not vacia
	boton_cocinar.text = "Cocinar guiso" if vacia else "Cocinar (la olla aún tiene guiso)"
	slider_mix.editable = vacia
	boton_servir_olla.visible = not vacia
	label_mezcla.text = d["mezcla"]
	var lista: Array = d["especias"]
	for i in botones_especia.size():
		var b: Button = botones_especia[i]
		if i < lista.size():
			var e: Dictionary = lista[i]
			b.visible = true
			b.text = "Echar %s (x%d)  ·  -%d%% sospecha" % [e["nombre"], e["cantidad"], e["pct"]]
			b.disabled = e["cantidad"] <= 0
		else:
			b.visible = false
	_on_slider(slider_mix.value)

func abrir_cobrador(deuda: float, pago: int, hay_guiso: bool) -> void:
	cerrar_todos()
	label_cobrador_texto.text = "«Debes %d monedas a la Mafia.\nO pagas, o nos das de comer.»" % int(ceil(deuda))
	boton_pagar.text = "Pagar $%d" % pago
	boton_entregar.disabled = not hay_guiso
	boton_entregar.text = "Entregar Guiso" if hay_guiso else "Entregar Guiso (no tienes guiso listo)"
	panel_cobrador.visible = true

func abrir_mejoras(d: Dictionary, monedas: int) -> void:
	cerrar_todos()
	label_mejoras_monedas.text = "Monedas: %d" % monedas
	if d["olla_doble"]:
		boton_olla_doble.text = "Olla Doble (comprada)"
	else:
		boton_olla_doble.text = "Olla Doble: cocina 2 platos a la vez ($%d)" % d["precio_olla_doble"]
	boton_olla_doble.disabled = d["olla_doble"] or monedas < d["precio_olla_doble"]
	if d["cortinas"]:
		boton_cortinas.text = "Cortinas del Callejón (compradas)"
	else:
		boton_cortinas.text = "Cortinas del Callejón: menos sospecha al cazar ($%d)" % d["precio_cortinas"]
	boton_cortinas.disabled = d["cortinas"] or monedas < d["precio_cortinas"]
	panel_mejoras.visible = true

func mostrar_fin(titulo: String, texto: String) -> void:
	cerrar_todos()
	panel_pausa.visible = false
	panel_inventario.visible = false
	label_fin_titulo.text = titulo
	label_fin_texto.text = texto
	panel_fin.visible = true

func _on_slider(valor: float) -> void:
	var g := int(round(valor / 100.0 * _raciones_guiso))
	label_mix.text = "Gato %d%% (%d)   /   Liebre %d%% (%d)" % [int(valor), g, 100 - int(valor), _raciones_guiso - g]
