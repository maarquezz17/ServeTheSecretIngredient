extends CharacterBody3D

signal fregona_soltada

const VELOCIDAD := 4.5
const GRAVEDAD := 20.0
const SENSIBILIDAD := 0.0025          # base; se multiplica por la sensibilidad elegida en Ajustes (SaveSystem)

# Zonas donde puede caer la fregona al soltarla (x_min, x_max, z_min, z_max): interior de la taberna y callejón.
const ZONA_TABERNA := Vector4(-7.4, 7.4, -5.4, 5.4)
const ZONA_CALLEJON := Vector4(9.0, 15.4, -5.2, 5.2)
const X_UMBRAL_CALLEJON := 8.2

@export var distancia_soltar: float = 1.1

@onready var camara: Camera3D = $Camara
@onready var rayo: RayCast3D = $Camara/Rayo
@onready var mano_fregona: Node3D = $Camara/FregonaMano

var controles_activos := true
var objetivo: Node = null
var fregona_equipada := false

func _ready() -> void:
	add_to_group("jugador")
	mano_fregona.visible = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _unhandled_input(event: InputEvent) -> void:
	if not controles_activos:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		girar_con_raton(event.relative)
	elif event.is_action_pressed("interact") and objetivo != null:
		objetivo.interactuar()
	elif event.is_action_pressed("drop_item"):
		soltar_fregona()

# Gira al jugador y la cámara según el movimiento del ratón, multiplicado por la sensibilidad de Ajustes.
func girar_con_raton(relativo: Vector2) -> void:
	var sensibilidad: float = SENSIBILIDAD * SaveSystem.sensibilidad_raton
	rotate_y(-relativo.x * sensibilidad)
	camara.rotate_x(-relativo.y * sensibilidad)
	camara.rotation.x = clampf(camara.rotation.x, -1.4, 1.4)

func _physics_process(delta: float) -> void:
	_actualizar_objetivo()
	if not controles_activos:
		velocity = Vector3.ZERO
		return
	if not is_on_floor():
		velocity.y -= GRAVEDAD * delta
	else:
		velocity.y = 0.0
	var dir := Input.get_vector("move_left", "move_right", "move_forward", "move_backward")
	var mov := (transform.basis * Vector3(dir.x, 0.0, dir.y)).normalized()
	velocity.x = mov.x * VELOCIDAD
	velocity.z = mov.z * VELOCIDAD
	move_and_slide()

func _actualizar_objetivo() -> void:
	objetivo = null
	if rayo.is_colliding():
		var c = rayo.get_collider()
		if c != null and c.has_method("interactuar"):
			objetivo = c

func set_controles(activos: bool) -> void:
	controles_activos = activos

func equipar_fregona() -> void:
	fregona_equipada = true
	mano_fregona.visible = true

# Suelta la fregona (tecla drop_item, por defecto F): sale de la mano y cae al suelo delante del jugador.
func soltar_fregona() -> bool:
	if not fregona_equipada:
		return false
	var fregona = get_tree().get_first_node_in_group("fregona")
	if fregona == null:
		return false
	fregona_equipada = false
	mano_fregona.visible = false
	var adelante := -global_transform.basis.z
	adelante.y = 0.0
	if adelante.length() < 0.01:
		adelante = Vector3(0.0, 0.0, -1.0)
	var destino := _limitar_a_zona(global_position + adelante.normalized() * distancia_soltar)
	fregona.soltar(destino, rotation.y)
	fregona_soltada.emit()
	return true

# Evita que la fregona caiga dentro de una pared: se queda dentro de la zona (taberna o callejón) donde está el jugador.
func _limitar_a_zona(punto: Vector3) -> Vector3:
	var zona: Vector4 = ZONA_CALLEJON if global_position.x > X_UMBRAL_CALLEJON else ZONA_TABERNA
	return Vector3(clampf(punto.x, zona.x, zona.y), 0.0, clampf(punto.z, zona.z, zona.w))
