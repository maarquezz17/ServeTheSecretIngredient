extends PanelContainer
# Panel de Ajustes (volumen, sensibilidad del ratón y reasignación de teclas).
# Se instancia en MainMenu.tscn y en UI.tscn (menú de pausa). Todo se guarda en SaveSystem (user://settings.json).

signal cerrado

const ACCIONES := ["interact", "drop_item", "inventario"]

@onready var slider_volumen: HSlider = $VBox/FilaVolumen/SliderVolumen
@onready var valor_volumen: Label = $VBox/FilaVolumen/ValorVolumen
@onready var slider_sensibilidad: HSlider = $VBox/FilaSensibilidad/SliderSensibilidad
@onready var valor_sensibilidad: Label = $VBox/FilaSensibilidad/ValorSensibilidad
@onready var botones_tecla := {
	"interact": $VBox/FilaInteractuar/BotonInteractuar,
	"drop_item": $VBox/FilaSoltar/BotonSoltar,
	"inventario": $VBox/FilaInventario/BotonInventario
}
@onready var label_aviso: Label = $VBox/LabelAviso
@onready var boton_restablecer: Button = $VBox/BotonRestablecer
@onready var boton_volver: Button = $VBox/BotonVolver

# Acción que está esperando una tecla nueva ("" = ninguna).
var _esperando := ""

func _ready() -> void:
	visible = false
	slider_volumen.min_value = 0.0
	slider_volumen.max_value = 1.0
	slider_volumen.step = 0.01
	slider_sensibilidad.min_value = SaveSystem.SENSIBILIDAD_MIN
	slider_sensibilidad.max_value = SaveSystem.SENSIBILIDAD_MAX
	slider_sensibilidad.step = 0.05
	slider_volumen.value_changed.connect(_on_volumen_cambiado)
	slider_sensibilidad.value_changed.connect(_on_sensibilidad_cambiada)
	# Al soltar el deslizador se guarda (también se guarda al cerrar el panel).
	slider_volumen.drag_ended.connect(func(_cambio: bool): SaveSystem.guardar_ajustes())
	slider_sensibilidad.drag_ended.connect(func(_cambio: bool): SaveSystem.guardar_ajustes())
	for accion in ACCIONES:
		botones_tecla[accion].pressed.connect(_on_boton_tecla.bind(accion))
	boton_restablecer.pressed.connect(_on_restablecer)
	boton_volver.pressed.connect(cerrar)

func abrir() -> void:
	_cancelar_espera()
	_sincronizar()
	label_aviso.text = "Pulsa un botón de tecla y luego la tecla nueva (Esc cancela)."
	visible = true
	boton_volver.grab_focus()

func cerrar() -> void:
	_cancelar_espera()
	SaveSystem.guardar_ajustes()
	visible = false
	cerrado.emit()

# Pone en pantalla los valores actuales sin disparar las señales de los controles.
func _sincronizar() -> void:
	slider_volumen.set_value_no_signal(SaveSystem.volumen_master)
	valor_volumen.text = "%d%%" % int(round(SaveSystem.volumen_master * 100.0))
	slider_sensibilidad.set_value_no_signal(SaveSystem.sensibilidad_raton)
	valor_sensibilidad.text = "x%.2f" % SaveSystem.sensibilidad_raton
	for accion in ACCIONES:
		botones_tecla[accion].text = SaveSystem.nombre_tecla(accion)

func _on_volumen_cambiado(valor: float) -> void:
	SaveSystem.set_volumen(valor)
	valor_volumen.text = "%d%%" % int(round(SaveSystem.volumen_master * 100.0))

func _on_sensibilidad_cambiada(valor: float) -> void:
	SaveSystem.set_sensibilidad(valor)
	valor_sensibilidad.text = "x%.2f" % SaveSystem.sensibilidad_raton

func _on_boton_tecla(accion: String) -> void:
	_cancelar_espera()
	_esperando = accion
	botones_tecla[accion].text = "Pulsa una tecla..."
	label_aviso.text = "Esperando tecla para «%s»... (Esc cancela)" % SaveSystem.ACCIONES_REASIGNABLES[accion]

func _on_restablecer() -> void:
	_cancelar_espera()
	SaveSystem.restablecer_controles()
	_sincronizar()
	label_aviso.text = "Controles restablecidos (E, F y Q)."

func _cancelar_espera() -> void:
	if _esperando != "":
		_esperando = ""
		_sincronizar()

# Mientras se espera una tecla, esta función la captura antes que el resto del juego.
func _input(evento: InputEvent) -> void:
	if _esperando == "":
		return
	if evento is InputEventKey and evento.pressed and not evento.echo:
		get_viewport().set_input_as_handled()
		if evento.physical_keycode == KEY_ESCAPE or evento.keycode == KEY_ESCAPE:
			_cancelar_espera()
			label_aviso.text = "Reasignación cancelada."
			return
		var accion := _esperando
		var error := SaveSystem.reasignar_accion(accion, evento)
		_esperando = ""
		_sincronizar()
		if error == "":
			label_aviso.text = "«%s» ahora es %s." % [SaveSystem.ACCIONES_REASIGNABLES[accion], SaveSystem.nombre_tecla(accion)]
		else:
			label_aviso.text = error

# Esc cierra el panel (si no se está esperando una tecla).
func _unhandled_input(evento: InputEvent) -> void:
	if visible and _esperando == "" and evento.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		cerrar()
