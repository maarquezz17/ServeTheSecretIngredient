extends Area3D
# Zona de paso con sonido (cortina del callejón, puerta...). Cuando el jugador entra en el Area3D suena su AudioStreamPlayer3D "Sonido".

@export var grupo_objetivo: StringName = &"jugador"
@export var variacion_tono: float = 0.08      # pequeño cambio aleatorio de tono para que no suene siempre igual

@onready var sonido: AudioStreamPlayer3D = $Sonido

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(cuerpo: Node3D) -> void:
	if not cuerpo.is_in_group(grupo_objetivo):
		return
	if sonido.playing:
		return
	sonido.pitch_scale = randf_range(1.0 - variacion_tono, 1.0 + variacion_tono)
	sonido.play()
