extends "res://scripts/interactuable.gd"
# Fregona apoyada en la pared de la cocina. Al interactuar, el jugador la equipa (game.gd) y desaparece del suelo.
# Con la tecla drop_item (F) el jugador la suelta: reaparece cayendo delante de él, tumbada en el suelo,
# y se puede volver a coger con E o dejarla donde está.

@export var altura_en_suelo: float = 0.14      # altura a la que reposa la fregona tumbada
@export var altura_de_caida: float = 0.9       # altura (la de la mano) desde la que cae

var equipada := false

var _pos_original := Vector3.ZERO
var _rot_original := Vector3.ZERO
var _tween_caida: Tween = null

@onready var colision: CollisionShape3D = $Colision

func _ready() -> void:
	super()
	tipo = "fregona"
	add_to_group("fregona")
	# Capa 2: no estorba al caminar (el jugador solo colisiona con la capa 1) pero el rayo de interacción sí la detecta.
	collision_layer = 2
	_pos_original = global_position
	_rot_original = rotation

func get_prompt() -> String:
	return "E: Coger la fregona"

func equipar() -> void:
	equipada = true
	_detener_caida()
	visible = false
	colision.set_deferred("disabled", true)

# Cae en "destino" (suelo) girada según "yaw": empieza en pie a la altura de la mano y termina tumbada en el suelo.
func soltar(destino: Vector3, yaw: float) -> void:
	equipada = false
	_detener_caida()
	rotation = Vector3(0.0, yaw, 0.15)
	global_position = Vector3(destino.x, altura_de_caida, destino.z)
	visible = true
	colision.set_deferred("disabled", false)
	_tween_caida = create_tween().set_parallel(true)
	_tween_caida.tween_property(self, "global_position:y", altura_en_suelo, 0.45).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	_tween_caida.tween_property(self, "rotation:z", PI * 0.5, 0.35).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)

# Devuelve la fregona a su sitio original apoyada en la pared de la cocina.
func devolver_a_pared() -> void:
	equipada = false
	_detener_caida()
	global_position = _pos_original
	rotation = _rot_original
	visible = true
	colision.set_deferred("disabled", false)

func _detener_caida() -> void:
	if _tween_caida != null and _tween_caida.is_valid():
		_tween_caida.kill()
	_tween_caida = null
