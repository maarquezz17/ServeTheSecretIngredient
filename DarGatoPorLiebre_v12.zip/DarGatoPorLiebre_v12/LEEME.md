# Dar Gato Por Liebre — v12 (Godot 4.7.2)

Abre `project.godot` y pulsa F5: el juego arranca en el **menú principal** (`scenes/MainMenu.tscn`, con fondo 3D de la taberna).
La resolución base es 1920×1080 (la interfaz se diseñó para 1280×720, por eso `window/stretch/scale = 1.5`).

## Novedades de esta versión
| Qué | Dónde |
|---|---|
| Menú principal (Jugar nueva partida / Cargar partida / Ajustes / Salir) | scenes/MainMenu.tscn + scripts/main_menu.gd |
| HUD reducido (Día, Monedas, Deuda, barra de Suspicacia, cobrador) | UI.tscn > HUD |
| Reloj grande arriba a la derecha (HH:MM) | UI.tscn > LabelReloj |
| Inventario oculto (se ve mientras mantienes Q) | UI.tscn > PanelInventario |
| Ciclo de día y noche (08:00 → 00:00) | scripts/game.gd (hora, luz del sol y ambiente) |
| Fregona apoyada en la pared izquierda de la cocina | Tavern.tscn > Cocina/Fregona + scripts/fregona.gd |
| Pool de 5 manchas/huellas | Tavern.tscn > Manchas/Mancha1..5 (cada una con un Area3D "Zona") + scripts/mancha.gd |
| Fregona en la mano del jugador | Player.tscn > Camara/FregonaMano |

## Cómo funciona
- **Menú:** "Jugar nueva partida" carga Main.tscn; "Cargar partida" restaura la partida guardada; "Salir" cierra el juego; "Ajustes" solo imprime un mensaje por ahora.
  En la pantalla final hay un botón "Menú principal".
- **Reloj:** el día empieza a las 08:00 y termina a las 00:00. Un día dura (hora_fin - hora_inicio) × segundos_por_hora (por defecto 16 × 30 s = 8 min).
  A medianoche empieza un día nuevo (clientes y gatos se reinician). Al avanzar la tarde baja la luz del sol y el ambiente.
- **Inventario:** mantén **Q** para ver gatos, liebres, especias, fregona y manchas pendientes. Se oculta al soltar y no se superpone a otros menús.
- **Manchas:** el pool está pre-colocado y oculto (`visible = false`, colisión desactivada). Cada vez que cocinas o consigues carne de gato se muestra una mancha al azar.
  Mientras haya manchas visibles la suspicacia sube sola (`sospecha_por_mancha_seg` por mancha y segundo).
  Coge la fregona (E) y apunta a una mancha (E) para ocultarla: baja la suspicacia (`reduccion_sospecha_limpieza`).
- Nada se crea por código: solo se alterna visibilidad y colisión de nodos ya presentes en las escenas.

## Novedades de la v12
**Soltar la fregona (F)** — `player.gd` + `fregona.gd`
- Acción `drop_item` (tecla F) en project.godot. Con la fregona equipada, F la suelta: sale de la mano y cae al suelo delante del jugador
  (tumbada, dentro de la taberna o del callejón según dónde estés). Se vuelve a coger con E. La fregona usa la capa de colisión 2:
  no estorba al caminar, pero el rayo de interacción la ve.

**Ajustes funcionales** — `scenes/SettingsMenu.tscn` + `scripts/settings_menu.gd`
- Accesibles desde el menú principal (botón Ajustes) y desde la pausa (Esc > Ajustes).
- Volumen general (HSlider sobre el bus Master de AudioServer), sensibilidad del ratón (HSlider; `player.gd` multiplica el giro por ese valor)
  y reasignación de Interactuar, Soltar e Inventario: al pulsar el botón el juego espera una tecla y la aplica con
  `InputMap.action_erase_events()` + `action_add_event()` (en Godot 4 no existe `InputMap.action_change_event()`).
  Rechaza teclas ya usadas (otra acción o movimiento); Esc cancela; "Restablecer controles" devuelve E, F y Q.
- Se guardan en `user://settings.json` mediante el autoload SaveSystem y se aplican al arrancar el juego. Son independientes de
  `user://savegame.json`, así que las partidas guardadas de versiones anteriores siguen funcionando.

**Audio espacial** — `assets/boil.wav`, `curtain.wav`, `meow.wav` (generados para el proyecto)
- `Cocina/Olla/Hervor` y `Cocina/Olla2/Hervor` (AudioStreamPlayer3D, autoplay, bucle, `max_distance` 5 m: solo se oye en la cocina; con guiso suena más fuerte).
- `Callejon/ZonaCortina` (Area3D + AudioStreamPlayer3D, script `zona_sonido.gd`): suena al pasar el jugador por la puerta del callejón.
- `Callejon/Trampas/TrampaX/Maullido`: `trampa.gd` lo reproduce al atrapar un gato.

**Personajes humanoides (solo nodos nativos en Tavern.tscn)**
- Clientes: pelvis y torso (BoxMesh escalado desde el nodo), cabeza, brazos, antebrazos, manos, muslos, pantorrillas y pies (cápsulas rotadas),
  pelo, nariz y ojos. El torso y las mangas cambian de color según el tipo (normal / borracho / inspector). El inspector lleva un sombrero elegante
  (cilindro con ala plana y cinta). Los clientes giran hacia donde caminan y se sientan mirando a su mesa.
- Cobrador: más alto (2,7 m con el sombrero), todo de negro, gabardina ancha (cápsula), hombreras, guantes, ojos rojos, maletín y sombrero de copa.

## Novedades de la v11
**Guardado y carga** (`scripts/save_system.gd`, Autoload "SaveSystem")
- Escribe/lee `user://savegame.json` con FileAccess: día, monedas, deuda, suspicacia, hora e inventario (liebres, gatos y cada especia).
- "Cargar partida" (menú) lee el archivo y al entrar en Main.tscn restaura todo. Está desactivado si no hay partida. "Jugar nueva partida" ignora el guardado.
- Guardar: **Esc** abre el menú de pausa (Continuar / Guardar partida / Menú principal) y además se **autoguarda al amanecer** de cada día
  (`autoguardar_cada_dia` en el nodo `Main`). La pausa detiene el reloj, los clientes y los gatos.
- Un archivo dañado o incompleto se rechaza sin romper el juego.

**Menú principal con fondo 3D** (`scenes/MainMenu.tscn`)
- Una vista 3D de la taberna dentro de la propia escena (SubViewportContainer > SubViewport > Escena): muros de piedra, vigas y suelo de madera,
  hogar con caldero humeante, mesa con velas y una terrina con un gato asomando, barriles, estante y el logo sobre la chimenea.
- Luces `OmniLight3D` cálidas (velas, hogar y apliques) que parpadean, contra rincones oscuros. Polvo flotando y humo (`GPUParticles3D`).
- Interfaz a la izquierda con un Theme global (`assets/tema_taberna.tres`): botones de madera oscura/hierro con borde biselado,
  texto claro y estilo distinto en hover/pulsado/foco/desactivado; además el botón crece al pasar el ratón.
- Todo (mallas, luces, partículas, Theme) está declarado en el .tscn: puedes mover o editar cualquier objeto en el viewport 3D.

**Game feel**
- **Olla viva:** `Cocina/Olla/Humo` y `Cocina/Olla2/Humo` (GPUParticles3D) emiten vapor blanco suave hacia arriba de forma continua;
  con guiso en la olla sale con más intensidad.
- **Feedback de interacción:** al interactuar con cualquier objeto (olla, trampa, frasco, fregona, cliente...) hace un botecito de escala y un temblor
  con Tween (parámetros `feedback_*` editables en el Inspector; `feedback_activo` lo desactiva por objeto).
- Los clientes siguen reciclándose con Tweens (mesa -> pasillo -> puerta), sin queue_free().

## Clientes que entran y salen caminando (v10)
- Tras comer, el cliente espera `tiempo_comiendo`, se levanta y camina **mesa → pasillo → puerta** con dos Tweens lineales encadenados
  (sin NavMesh). Al llegar a la puerta se oculta, desactiva su colisión y arranca su `Timer` (`TimerEspera`, entre `espera_min` y `espera_max` segundos).
  Cuando el Timer acaba reaparece en la puerta con un `TipoCliente` nuevo y camina **puerta → pasillo → su mesa** (`posicion_mesa`, guardada al empezar).
- Mientras camina no se le puede servir ("Cliente en camino").
- Waypoints editables en el viewport: `Tavern > Waypoints` (`Puerta` y `Pasillo1..4`, nodos Marker3D). Cada cliente tiene asignados
  `nodo_puerta` y `nodo_pasillo` en el Inspector. Si mueves una mesa, mueve también su pasillo para que la ruta siga libre.
- Los pasillos están elegidos para no cruzar mesas, sillas ajenas ni otros clientes (comprobado automáticamente).
- Si un cliente tiene vacíos `nodo_puerta` o `nodo_pasillo`, no camina: desaparece y vuelve directamente a su mesa (y avisa en la consola).
- El "servicio completado" (baja la suspicacia) ahora se cuenta por clientes servidos: al servir tantos como clientes hay.
  Los clientes ya no se reinician todos a la vez ni al amanecer: cada uno se recicla solo.

## Editar a mano
- Las manchas están ocultas en el .tscn tal como se pidió: para verlas en el viewport, activa el ojo de `Manchas/ManchaN` y, si quieres probarlo en juego, deja `visible` como estaba.
  Puedes moverlas, rotarlas o cambiarles el material; su Area3D (`Zona`) cuelga de cada una.
- Parámetros de equilibrio (reloj, manchas, deuda, precios…): selecciona el nodo `Main` y edita sus variables exportadas.
- Nombres que los scripts esperan: Cocina/Olla, Cocina/Olla2, Cocina/Pizarra, Cocina/Fregona, Callejon/Cortinas, Mafia/Cobrador, Manchas, Waypoints, Comedor/ClienteN/TimerEspera, Luces/Sol, Camara/FregonaMano, Cocina/Olla/Hervor, Cocina/Olla/Humo, Cocina/Olla2/Humo.
- Las zonas de detección de las trampas están en la capa de colisión 0 para que no tapen el raycast del jugador (siguen detectando gatos por su máscara).

## Cómo se juega
WASD mover · ratón mirar · E interactuar · F soltar la fregona · Q inventario (mantener) · Esc cierra menús o abre la pausa. (E, F y Q se pueden cambiar en Ajustes.)
- Gatos: atrápalos a mano (a menudo se escapan) o espera a que caigan en una trampa-jaula y recógela.
- Especias: compra en el estante; se guardan y se echan desde el menú de la olla (antes de cocinar o sobre un guiso hecho).
- Clientes: NORMAL, BORRACHO (impacto 0) o INSPECTOR (sombrero, impacto x3). Se asignan al azar.
- Cobrador: al agotarse `tiempo_deuda` aparece ante la puerta: "Pagar $X" o "Entregar Guiso" (liebre pura te perdona el interés; con gato sube la deuda y bloquea la olla 30 s).
- Pizarra: Olla Doble y Cortinas del callejón.
Ganas saldando la deuda; pierdes con 100 % de suspicacia o si la deuda llega a `deuda_limite`.
