extends StaticBody3D
# Base de todo objeto con el que el jugador puede interactuar (E).
# Editable desde el Inspector: "tipo" y "prompt".

signal interactuado(objeto)

@export var tipo: String = ""
@export var prompt: String = "E: Interactuar"

func _ready() -> void:
	add_to_group("interactuable")

func get_prompt() -> String:
	return prompt

func interactuar() -> void:
	interactuado.emit(self)
