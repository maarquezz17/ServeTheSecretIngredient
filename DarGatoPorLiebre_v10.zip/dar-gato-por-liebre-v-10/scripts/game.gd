extends Node3D

# Parámetros de equilibrio: editables en el Inspector al seleccionar el nodo Main.
@export var deuda_inicial: float = 150.0
@export var deuda_limite: float = 300.0
@export var interes_por_visita: float = 0.10
@export var tiempo_deuda: float = 120.0          # segundos hasta que llega el cobrador
@export var paciencia_cobrador: float = 60.0     # segundos que espera ante la puerta
@export var cuota_pago: float = 35.0
@export var penalizacion_deuda: float = 30.0
@export var bloqueo_olla_segundos: float = 30.0
@export var monedas_iniciales: int = 40
@export var liebres_iniciales: int = 2
@export var precio_liebre: int = 5
@export var precio_racion: int = 14
@export var raciones_por_guiso: int = 4
@export var sospecha_por_exceso: float = 60.0
@export var sospecha_por_captura: float = 4.0    # sospecha pasiva por cada gato cazado
@export var bajada_sospecha_servicio: float = 15.0
@export var bajada_sospecha_dia: float = 10.0
# Reloj: el día va de hora_inicio a hora_fin (24.0 = medianoche). Un día dura (hora_fin - hora_inicio) * segundos_por_hora.
@export var hora_inicio: float = 8.0
@export var hora_fin: float = 24.0
@export var segundos_por_hora: float = 30.0
# Manchas / huellas
@export var sospecha_por_mancha_seg: float = 0.08   # sospecha pasiva por segundo y por mancha visible
@export var reduccion_sospecha_limpieza: float = 4.0

@onready var tavern = $Tavern
@onready var player = $Player
@onready var ui = $UI
@onready var world_env: WorldEnvironment = $WorldEnvironment

var dia := 1
var monedas := 0
var deuda := 0.0
var sospecha := 0.0
var gatos := 0
var liebres := 0
var terminado := false
var servidos_servicio := 0   # clientes servidos desde el último "servicio completado"

var hora := 8.0
var _sol_energia_base := 1.0
var _ambiente_energia_base := 1.0
var _fondo_base := Color.BLACK
var _acum_hud := 0.0

var especias := {}                # nombre -> raciones guardadas en el almacén
var catalogo_especias: Array = [] # [{nombre, reduccion, precio}] en el orden del estante
var mezcla_pendiente: Array = []  # especias añadidas al guiso que aún no se ha cocinado

var tiempo_restante := 0.0
var paciencia_restante := 0.0
var interes_ultima_visita := 0.0

var olla_actual = null      # olla cuyo menú está abierto
var olla_servicio = null    # olla de la que se sirve a los clientes

func _ready() -> void:
	monedas = monedas_iniciales
	deuda = deuda_inicial
	liebres = liebres_iniciales
	tiempo_restante = tiempo_deuda
	hora = hora_inicio
	# Copia del Environment para que el ciclo día/noche no modifique el recurso compartido de la escena.
	world_env.environment = world_env.environment.duplicate()
	_sol_energia_base = tavern.sol.light_energy
	_ambiente_energia_base = world_env.environment.ambient_light_energy
	_fondo_base = world_env.environment.background_color
	for n in get_tree().get_nodes_in_group("interactuable"):
		n.interactuado.connect(_on_interactuado)
	for t in get_tree().get_nodes_in_group("trampas"):
		t.gato_atrapado.connect(_on_gato_atrapado)
	_construir_catalogo_especias()
	ui.cocinar_solicitado.connect(_on_cocinar_solicitado)
	ui.especia_solicitada.connect(_on_especia_solicitada)
	ui.servir_olla_solicitado.connect(_on_servir_olla)
	ui.cocina_cerrada.connect(_cerrar_menus)
	ui.pagar_solicitado.connect(_on_pagar)
	ui.entregar_solicitado.connect(_on_entregar)
	ui.cobrador_cerrado.connect(_cerrar_menus)
	ui.mejora_solicitada.connect(_on_mejora_solicitada)
	ui.mejoras_cerradas.connect(_cerrar_menus)
	ui.reinicio_solicitado.connect(_reiniciar)
	ui.menu_solicitado.connect(_ir_al_menu)
	_refrescar_hud()
	_actualizar_reloj()
	ui.mostrar_mensaje("Caza gatos (o usa las trampas), cocina y sirve. Cuidado con las manchas y con el cobrador de la mafia.", 6.0)

func _process(delta: float) -> void:
	if terminado:
		ui.mostrar_prompt("")
		return
	_avanzar_tiempo(delta)
	if terminado:
		return
	_actualizar_manchas(delta)
	_actualizar_cobrador(delta)
	if ui.hay_menu_abierto():
		ui.mostrar_prompt("")
		return
	var o = player.objetivo
	ui.mostrar_prompt(o.get_prompt() if is_instance_valid(o) else "")

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and not terminado:
		if ui.hay_menu_abierto():
			_cerrar_menus()
		elif Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		else:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

# ───────────────────────── Interacciones ─────────────────────────
func _on_interactuado(obj) -> void:
	if terminado:
		return
	match obj.tipo:
		"olla":
			_usar_olla(obj)
		"despensa":
			_comprar_liebre()
		"gato":
			_capturar_gato(obj)
		"cliente":
			_servir_cliente(obj)
		"trampa":
			_recoger_trampa(obj)
		"especia":
			_coger_especia(obj)
		"cobrador":
			_abrir_cobrador()
		"mejoras":
			_abrir_mejoras()
		"fregona":
			_equipar_fregona(obj)
		"mancha":
			_limpiar_mancha(obj)

func _abrir_menu() -> void:
	player.set_controles(false)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _cerrar_menus() -> void:
	_devolver_mezcla_pendiente()
	ui.cerrar_todos()
	olla_actual = null
	if not terminado:
		player.set_controles(true)
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

# ───────────────────────── Cocina y especias ─────────────────────────
func _construir_catalogo_especias() -> void:
	catalogo_especias.clear()
	especias.clear()
	for f in get_tree().get_nodes_in_group("especias"):
		if especias.has(f.nombre):
			continue
		catalogo_especias.append({"nombre": f.nombre, "reduccion": f.reduccion, "precio": f.precio})
		especias[f.nombre] = 0

# La olla siempre abre su menú: desde ahí se cocina, se echan especias guardadas o se elige para servir.
func _usar_olla(olla) -> void:
	if olla.bloqueada():
		ui.mostrar_mensaje("La olla está bloqueada %d s más." % int(ceil(olla.bloqueo_restante)))
		return
	olla_actual = olla
	mezcla_pendiente.clear()
	_abrir_menu()
	ui.abrir_cocina(_datos_cocina())

func _datos_cocina() -> Dictionary:
	var lista: Array = []
	for e in catalogo_especias:
		lista.append({"nombre": e["nombre"], "cantidad": especias[e["nombre"]], "pct": int(round(e["reduccion"] * 100.0))})
	var estado := "Olla vacía"
	var mezcla := ""
	if olla_actual.raciones > 0:
		estado = "Guiso: %d raciones · %d%% gato · sospecha %d%%" % [olla_actual.raciones, int(round(olla_actual.pct_gato * 100.0)), int(round(olla_actual.sospecha_acumulada * 100.0))]
		mezcla = "Las especias se echan directamente al guiso de la olla."
	elif mezcla_pendiente.is_empty():
		mezcla = "Las especias que añadas ahora se mezclarán con el próximo guiso."
	else:
		mezcla = "En la mezcla: " + ", ".join(mezcla_pendiente)
	return {
		"raciones_guiso": raciones_por_guiso, "olla_vacia": olla_actual.raciones <= 0, "estado_olla": estado,
		"gatos": gatos, "liebres": liebres, "especias": lista, "mezcla": mezcla
	}

func _on_cocinar_solicitado(proporcion: float) -> void:
	if olla_actual == null or olla_actual.raciones > 0:
		return
	var g := int(round(proporcion * raciones_por_guiso))
	var l := raciones_por_guiso - g
	if gatos < g:
		ui.mostrar_mensaje("Te faltan raciones de gato (necesitas %d)." % g)
		return
	if liebres < l:
		ui.mostrar_mensaje("Te falta liebre (necesitas %d). Cómprala en la despensa." % l)
		return
	gatos -= g
	liebres -= l
	olla_actual.cocinar(raciones_por_guiso, float(g) / float(raciones_por_guiso))
	for nombre in mezcla_pendiente:
		olla_actual.reducir_sospecha(_reduccion_de(nombre))
	mezcla_pendiente.clear()
	_marcar_servicio(olla_actual)
	var sosp := int(round(olla_actual.sospecha_acumulada * 100.0))
	_ensuciar()
	_cerrar_menus()
	_refrescar_hud()
	ui.mostrar_mensaje("Guiso listo: %d%% gato, sospecha del guiso %d%%." % [int(round(proporcion * 100.0)), sosp])

func _on_especia_solicitada(indice: int) -> void:
	if olla_actual == null or indice >= catalogo_especias.size():
		return
	var e: Dictionary = catalogo_especias[indice]
	var nombre: String = e["nombre"]
	if especias[nombre] <= 0:
		ui.mostrar_mensaje("No te queda %s. Cómprala en el estante." % nombre)
		return
	especias[nombre] -= 1
	if olla_actual.raciones > 0:
		olla_actual.reducir_sospecha(e["reduccion"])
		ui.mostrar_mensaje("Echas %s al guiso: sospecha %d%%." % [nombre, int(round(olla_actual.sospecha_acumulada * 100.0))])
	else:
		mezcla_pendiente.append(nombre)
		ui.mostrar_mensaje("%s añadido a la mezcla." % nombre)
	_refrescar_hud()
	ui.actualizar_cocina(_datos_cocina())

func _on_servir_olla() -> void:
	if olla_actual == null or olla_actual.raciones <= 0:
		return
	_marcar_servicio(olla_actual)
	var racs: int = olla_actual.raciones
	_cerrar_menus()
	ui.mostrar_mensaje("Servirás a los clientes desde esta olla (%d raciones)." % racs)

# Si cierras el menú sin cocinar, las especias de la mezcla vuelven al almacén.
func _devolver_mezcla_pendiente() -> void:
	for nombre in mezcla_pendiente:
		especias[nombre] += 1
	if not mezcla_pendiente.is_empty():
		mezcla_pendiente.clear()
		_refrescar_hud()

func _reduccion_de(nombre: String) -> float:
	for e in catalogo_especias:
		if e["nombre"] == nombre:
			return e["reduccion"]
	return 0.0

func _marcar_servicio(olla) -> void:
	olla_servicio = olla
	for o in get_tree().get_nodes_in_group("ollas"):
		o.marcar_servicio(o == olla)

func _olla_con_guiso():
	if olla_servicio != null and olla_servicio.activa and olla_servicio.raciones > 0 and not olla_servicio.bloqueada():
		return olla_servicio
	for o in get_tree().get_nodes_in_group("ollas"):
		if o.activa and o.raciones > 0 and not o.bloqueada():
			return o
	return null

# Comprar un frasco lo guarda en el almacén; el orden respecto a cocinar da igual.
func _coger_especia(frasco) -> void:
	if monedas < frasco.precio:
		ui.mostrar_mensaje("No tienes monedas para %s (%d)." % [frasco.nombre, frasco.precio])
		return
	monedas -= frasco.precio
	especias[frasco.nombre] = especias.get(frasco.nombre, 0) + 1
	_refrescar_hud()
	ui.mostrar_mensaje("Guardas %s (tienes %d). Úsala desde el menú de la olla." % [frasco.nombre, especias[frasco.nombre]])

func _texto_especias(separador: String = "\n") -> String:
	var partes: Array = []
	for e in catalogo_especias:
		partes.append("%s: %d" % [e["nombre"], especias[e["nombre"]]])
	return separador.join(partes)

func _comprar_liebre() -> void:
	if monedas < precio_liebre:
		ui.mostrar_mensaje("No tienes monedas para comprar liebre.")
		return
	monedas -= precio_liebre
	liebres += 1
	_refrescar_hud()
	ui.mostrar_mensaje("Compras una ración de liebre (-%d monedas)." % precio_liebre)

# ───────────────────────── Gatos y trampas ─────────────────────────
func _capturar_gato(gato) -> void:
	if randf() > gato.prob_captura_manual:
		gato.asustar(player.global_position)
		ui.mostrar_mensaje("¡El gato se te escapa! Las trampas son más fiables.")
		return
	gato.capturar()
	_ganar_gato(gato.raciones)

func _recoger_trampa(trampa) -> void:
	if not trampa.llena:
		ui.mostrar_mensaje("La trampa está vacía. Espera a que caiga un gato.")
		return
	_ganar_gato(trampa.recoger())

func _on_gato_atrapado(_trampa) -> void:
	ui.mostrar_mensaje("¡Una trampa del callejón ha atrapado un gato!")

func _ganar_gato(raciones: int) -> void:
	gatos += raciones
	var mult := 1.0
	if is_instance_valid(tavern.pizarra):
		mult = tavern.pizarra.multiplicador_captura()
	sospecha = minf(100.0, sospecha + sospecha_por_captura * mult)
	_ensuciar()
	_refrescar_hud()
	ui.mostrar_mensaje("Carne de gato conseguida: +%d raciones." % raciones)
	if sospecha >= 100.0:
		_terminar("¡DESCUBIERTO!", "Los vecinos han visto demasiados gatos desaparecer.")

# ───────────────────────── Clientes ─────────────────────────
func _servir_cliente(cliente) -> void:
	if not cliente.puede_servirse():
		if not cliente.atendido:
			ui.mostrar_mensaje("El cliente todavía no se ha sentado.")
		return
	var olla = _olla_con_guiso()
	if olla == null:
		ui.mostrar_mensaje("No hay guiso listo (o la olla está bloqueada).")
		return
	var impacto: float = cliente.impacto_sospecha(olla.sospecha_acumulada, sospecha_por_exceso)
	olla.servir_racion()
	cliente.atender(impacto)
	monedas += precio_racion
	sospecha = minf(100.0, sospecha + impacto)
	_refrescar_hud()
	if sospecha >= 100.0:
		_terminar("¡DESCUBIERTO!", "La taberna entera sabe lo que hay en tu guiso. Te echan a palos.")
		return
	servidos_servicio += 1
	if servidos_servicio >= get_tree().get_nodes_in_group("clientes").size():
		servidos_servicio = 0
		_nuevo_servicio()

# Los clientes salen y vuelven a entrar por su cuenta (cliente.gd); aquí solo se premia haber servido a todos.
func _nuevo_servicio() -> void:
	sospecha = maxf(0.0, sospecha - bajada_sospecha_servicio)
	_refrescar_hud()
	ui.mostrar_mensaje("Servicio completado: los clientes comentan que se come bien. Baja la suspicacia.", 4.0)

# ───────────────────────── Reloj y ciclo de día y noche ─────────────────────────
func _avanzar_tiempo(delta: float) -> void:
	hora += delta / maxf(0.1, segundos_por_hora)
	if hora >= hora_fin:
		_nuevo_dia()
	_actualizar_reloj()
	_aplicar_luz()

func _nuevo_dia() -> void:
	dia += 1
	hora = hora_inicio
	sospecha = maxf(0.0, sospecha - bajada_sospecha_dia)
	tavern.reiniciar_dia()
	_refrescar_hud()
	ui.mostrar_mensaje("Amanece en la taberna. Día %d." % dia, 4.0)

func texto_hora() -> String:
	var h := int(floor(hora)) % 24
	var m := int(floor((hora - floor(hora)) * 60.0))
	return "%02d:%02d" % [h, m]

func _actualizar_reloj() -> void:
	ui.actualizar_hora(texto_hora())

# Luz exterior según la hora: amanecer suave, mediodía, atardecer y noche cerrada.
func factor_luz(h: float) -> float:
	var puntos := [[8.0, 0.65], [14.0, 1.0], [19.0, 0.8], [22.0, 0.4], [24.0, 0.2]]
	if h <= puntos[0][0]:
		return puntos[0][1]
	for i in range(puntos.size() - 1):
		if h <= puntos[i + 1][0]:
			var t := inverse_lerp(puntos[i][0], puntos[i + 1][0], h)
			return lerpf(puntos[i][1], puntos[i + 1][1], t)
	return puntos[puntos.size() - 1][1]

func _aplicar_luz() -> void:
	var f := factor_luz(hora)
	tavern.sol.light_energy = _sol_energia_base * f
	world_env.environment.ambient_light_energy = _ambiente_energia_base * lerpf(0.5, 1.0, f)
	world_env.environment.background_color = _fondo_base * lerpf(0.4, 1.0, f)

# ───────────────────────── Manchas y fregona ─────────────────────────
# Las manchas son un pool pre-colocado en Tavern.tscn: aquí solo se alterna su visibilidad/colisión.
func _ensuciar() -> void:
	var libres: Array = get_tree().get_nodes_in_group("manchas").filter(func(m): return not m.activa)
	if libres.is_empty():
		return
	libres.pick_random().activar()

func manchas_visibles() -> int:
	return get_tree().get_nodes_in_group("manchas").filter(func(m): return m.activa).size()

# Cada mancha visible sube la suspicacia poco a poco.
func _actualizar_manchas(delta: float) -> void:
	var n := manchas_visibles()
	if n == 0:
		return
	sospecha = minf(100.0, sospecha + float(n) * sospecha_por_mancha_seg * delta)
	_acum_hud += delta
	if _acum_hud >= 0.25:
		_acum_hud = 0.0
		_refrescar_hud()
	if sospecha >= 100.0:
		_terminar("¡DESCUBIERTO!", "La taberna está tan sucia y rara que los clientes han empezado a preguntar.")

func _equipar_fregona(fregona) -> void:
	fregona.equipar()
	player.equipar_fregona()
	_refrescar_hud()
	ui.mostrar_mensaje("Coges la fregona. Apunta a una mancha y pulsa E para limpiarla.")

func _limpiar_mancha(mancha) -> void:
	if not player.fregona_equipada:
		ui.mostrar_mensaje("Necesitas la fregona (está apoyada en la pared de la cocina).")
		return
	mancha.limpiar()
	sospecha = maxf(0.0, sospecha - reduccion_sospecha_limpieza)
	_refrescar_hud()
	ui.mostrar_mensaje("Mancha limpiada: la suspicacia baja un poco.")

# ───────────────────────── Cobrador de la Mafia ─────────────────────────
func _actualizar_cobrador(delta: float) -> void:
	if tavern.cobrador.presente:
		paciencia_restante -= delta
		ui.actualizar_cobro("¡COBRADOR EN LA PUERTA! (%d s)" % int(ceil(maxf(0.0, paciencia_restante))))
		if paciencia_restante <= 0.0:
			_cobrador_pierde_paciencia()
	else:
		tiempo_restante -= delta
		ui.actualizar_cobro("Cobrador en: %d s" % int(ceil(maxf(0.0, tiempo_restante))))
		if tiempo_restante <= 0.0:
			_llega_cobrador()

func _llega_cobrador() -> void:
	interes_ultima_visita = deuda * interes_por_visita
	deuda += interes_ultima_visita
	paciencia_restante = paciencia_cobrador
	tavern.cobrador.aparecer()
	_refrescar_hud()
	ui.mostrar_mensaje("¡El cobrador de la mafia está en la puerta! (+%d de interés)" % int(round(interes_ultima_visita)), 5.0)
	if deuda >= deuda_limite:
		_terminar("LA MAFIA CUMPLE", "La deuda superó las %d monedas. Te quedas sin taberna." % int(deuda_limite))

func _cobrador_pierde_paciencia() -> void:
	deuda += penalizacion_deuda
	ui.mostrar_mensaje("El cobrador se cansa de esperar: +%d de deuda." % int(penalizacion_deuda), 4.0)
	_cobrador_se_va()
	if deuda >= deuda_limite:
		_terminar("LA MAFIA CUMPLE", "La deuda superó las %d monedas. Te quedas sin taberna." % int(deuda_limite))

func _cobrador_se_va() -> void:
	tavern.cobrador.ocultar()
	tiempo_restante = tiempo_deuda
	_cerrar_menus()
	_refrescar_hud()

func _abrir_cobrador() -> void:
	if not tavern.cobrador.presente:
		return
	_abrir_menu()
	ui.abrir_cobrador(deuda, int(ceil(minf(cuota_pago, deuda))), _olla_con_guiso() != null)

func _on_pagar() -> void:
	var pago := int(ceil(minf(cuota_pago, deuda)))
	if monedas < pago:
		ui.mostrar_mensaje("No tienes $%d para pagar." % pago)
		return
	monedas -= pago
	deuda -= pago
	if deuda <= 0.0:
		deuda = 0.0
		_refrescar_hud()
		_terminar("¡LIBRE!", "Saldaste la deuda con la mafia en el día %d. Y nadie lo sospecha." % dia)
		return
	_cobrador_se_va()
	ui.mostrar_mensaje("Pagas $%d. El cobrador se marcha... por ahora." % pago)

func _on_entregar() -> void:
	var olla = _olla_con_guiso()
	if olla == null:
		ui.mostrar_mensaje("No tienes guiso listo para entregar.")
		return
	var con_gato: bool = olla.pct_gato > 0.0
	olla.servir_racion()
	if con_gato:
		deuda += penalizacion_deuda
		olla.bloquear(bloqueo_olla_segundos)
		_cobrador_se_va()
		ui.mostrar_mensaje("¡Sabe a gato! +%d de deuda y la olla queda bloqueada %d s." % [int(penalizacion_deuda), int(bloqueo_olla_segundos)], 5.0)
		if deuda >= deuda_limite:
			_terminar("LA MAFIA CUMPLE", "La deuda superó las %d monedas. Te quedas sin taberna." % int(deuda_limite))
	else:
		deuda = maxf(0.0, deuda - interes_ultima_visita)
		_cobrador_se_va()
		ui.mostrar_mensaje("Guiso de liebre: el cobrador se relame y te perdona el interés de esta visita.", 5.0)

# ───────────────────────── Mejoras ─────────────────────────
func _abrir_mejoras() -> void:
	_abrir_menu()
	ui.abrir_mejoras(tavern.pizarra.estado(), monedas)

func _on_mejora_solicitada(id: String) -> void:
	var p = tavern.pizarra
	if p.ya_comprada(id):
		ui.mostrar_mensaje("Esa mejora ya está comprada.")
		return
	var coste: int = p.precio(id)
	if monedas < coste:
		ui.mostrar_mensaje("No tienes monedas suficientes.")
		return
	monedas -= coste
	p.aplicar(id)
	_refrescar_hud()
	ui.abrir_mejoras(p.estado(), monedas)
	if id == "olla_doble":
		ui.mostrar_mensaje("¡Segunda olla instalada en el mostrador!")
	else:
		ui.mostrar_mensaje("Cortinas puestas: cazar gatos levanta menos sospechas.")

# ───────────────────────── Fin de partida y HUD ─────────────────────────
func _terminar(titulo: String, texto: String) -> void:
	terminado = true
	player.set_controles(false)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	ui.mostrar_fin(titulo, texto)

func _reiniciar() -> void:
	get_tree().reload_current_scene()

func _ir_al_menu() -> void:
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

func _refrescar_hud() -> void:
	ui.actualizar_hud({
		"dia": dia, "monedas": monedas, "deuda": deuda, "deuda_max": deuda_limite,
		"sospecha": sospecha, "gatos": gatos, "liebres": liebres,
		"especias": _texto_especias(), "fregona": player.fregona_equipada, "manchas": manchas_visibles()
	})
