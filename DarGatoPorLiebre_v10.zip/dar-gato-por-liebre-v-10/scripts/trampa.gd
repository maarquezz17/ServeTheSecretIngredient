extends "res://scripts/interactuable.gd"
# Trampa-jaula del callejón. Cuando un gato entra en su Area3D ("Zona"), lo captura: la jaula cambia
# de color, aparece el gato dentro y pasa a ser interactuable para recoger la carne.

signal gato_atrapado(trampa)

@export var color_llena: Color = Color(0.9, 0.2, 0.15, 0.45)

var llena := false
var raciones := 0

var _color_vacia := Color.WHITE
var _material: StandardMaterial3D = null

@onready var caja: MeshInstance3D = $Caja
@onready var zona: Area3D = $Zona
@onready var gato_dentro: Node3D = $GatoDentro

func _ready() -> void:
	super()
	tipo = "trampa"
	add_to_group("trampas")
	# Copia del material para no modificar el recurso compartido de la escena.
	_material = caja.material_override.duplicate()
	caja.material_override = _material
	_color_vacia = _material.albedo_color
	gato_dentro.visible = false
	zona.body_entered.connect(_on_zona_body_entered)

func get_prompt() -> String:
	if llena:
		return "E: Recoger carne de gato (%d raciones)" % raciones
	return "Trampa para gatos (vacía, esperando una presa)"

func _on_zona_body_entered(cuerpo: Node3D) -> void:
	if llena or cuerpo == self:
		return
	if not cuerpo.is_in_group("gatos") or cuerpo.capturado:
		return
	raciones = cuerpo.raciones
	cuerpo.capturar()
	llena = true
	_material.albedo_color = color_llena
	gato_dentro.visible = true
	gato_atrapado.emit(self)

func recoger() -> int:
	var r := raciones
	resetear()
	return r

func resetear() -> void:
	llena = false
	raciones = 0
	_material.albedo_color = _color_vacia
	gato_dentro.visible = false
