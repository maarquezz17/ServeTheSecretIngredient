extends "res://scripts/interactuable.gd"
# Cliente de la taberna. Tras comer se levanta, sale andando (mesa -> pasillo -> puerta), espera fuera
# un tiempo y vuelve a entrar con un tipo nuevo. Sin NavMesh: dos movimientos lineales encadenados con Tweens.

enum TipoCliente { NORMAL, BORRACHO, INSPECTOR }
enum Estado { SENTADO, SALIENDO, FUERA, ENTRANDO }

# Proporción de sospecha del guiso que su paladar tolera (0.0 - 1.0).
@export_range(0.0, 1.0, 0.05) var tolerancia: float = 0.3
@export_range(0.0, 1.0, 0.05) var prob_borracho: float = 0.2
@export_range(0.0, 1.0, 0.05) var prob_inspector: float = 0.2
@export var multiplicador_inspector: float = 3.0
# Para probar un tipo concreto desde el Inspector sin depender del azar.
@export var forzar_tipo: bool = false
@export var tipo_forzado: TipoCliente = TipoCliente.NORMAL

# Waypoints: la puerta de la taberna y un punto intermedio libre de colisiones entre su mesa y la puerta.
@export var nodo_puerta: Node3D
@export var nodo_pasillo: Node3D
@export var velocidad_caminar: float = 1.4      # metros por segundo
@export var tiempo_comiendo: float = 2.5        # pausa tras comer antes de levantarse
@export var espera_min: float = 8.0             # segundos fuera antes de volver a entrar
@export var espera_max: float = 16.0

var tipo_cliente: TipoCliente = TipoCliente.NORMAL
var atendido := false
var estado: Estado = Estado.SENTADO
var posicion_mesa := Vector3.ZERO

var _tween: Tween = null

@onready var burbuja: Label3D = $Burbuja
@onready var sombrero: MeshInstance3D = $Sombrero
@onready var colision: CollisionShape3D = $Colision
@onready var timer_espera: Timer = $TimerEspera

func _ready() -> void:
	super()
	tipo = "cliente"
	add_to_group("clientes")
	posicion_mesa = global_position
	timer_espera.one_shot = true
	timer_espera.timeout.connect(_entrar)
	reiniciar()

func get_prompt() -> String:
	if estado != Estado.SENTADO:
		return "Cliente en camino"
	if atendido:
		return "Este cliente ya ha comido"
	return "E: Servir guiso"

# Solo se puede servir a un cliente sentado y que aún no ha comido.
func puede_servirse() -> bool:
	return estado == Estado.SENTADO and not atendido

# Se llama al aparecer cada cliente (inicio y cada vez que vuelve a entrar): asigna el tipo al azar.
func reiniciar() -> void:
	atendido = false
	if forzar_tipo:
		tipo_cliente = tipo_forzado
	else:
		var r := randf()
		if r < prob_inspector:
			tipo_cliente = TipoCliente.INSPECTOR
		elif r < prob_inspector + prob_borracho:
			tipo_cliente = TipoCliente.BORRACHO
		else:
			tipo_cliente = TipoCliente.NORMAL
	sombrero.visible = tipo_cliente == TipoCliente.INSPECTOR
	match tipo_cliente:
		TipoCliente.INSPECTOR:
			burbuja.text = "¡Hambre!"
		TipoCliente.BORRACHO:
			burbuja.text = "¡Hic! ¡Hambre!"
		_:
			burbuja.text = "¡Hambre! (paladar %s)" % _paladar()

# Cuánta suspicacia (en puntos de la barra) provoca servirle un guiso con esa sospecha acumulada.
func impacto_sospecha(sospecha_guiso: float, factor: float) -> float:
	match tipo_cliente:
		TipoCliente.BORRACHO:
			return 0.0
		TipoCliente.INSPECTOR:
			return maxf(0.0, sospecha_guiso - tolerancia) * factor * multiplicador_inspector
		_:
			return maxf(0.0, sospecha_guiso - tolerancia) * factor

func atender(impacto: float) -> void:
	atendido = true
	if tipo_cliente == TipoCliente.BORRACHO:
		burbuja.text = "¡Hic! ¡Qué rico!"
	elif impacto > 0.0 and tipo_cliente == TipoCliente.INSPECTOR:
		burbuja.text = "Mmm... esto me huele a gato. Lo anotaré."
	elif impacto > 0.0:
		burbuja.text = "Hmm... ¿esto sabe a gato?"
	else:
		burbuja.text = "¡Delicioso!"
	_salir()

# ───────────────────────── Salida: mesa -> pasillo -> puerta ─────────────────────────
func _salir() -> void:
	estado = Estado.SALIENDO
	_detener_tween()
	if not _hay_waypoints():
		_on_salida_terminada()
		return
	var pasillo := nodo_pasillo.global_position
	var puerta := nodo_puerta.global_position
	_tween = create_tween()
	_tween.tween_interval(tiempo_comiendo)
	_tween.tween_callback(_vaciar_burbuja)
	_tween.tween_property(self, "global_position", pasillo, _duracion(global_position, pasillo))
	_tween.tween_property(self, "global_position", puerta, _duracion(pasillo, puerta))
	_tween.tween_callback(_on_salida_terminada)

func _on_salida_terminada() -> void:
	estado = Estado.FUERA
	visible = false
	colision.set_deferred("disabled", true)
	timer_espera.start(randf_range(espera_min, maxf(espera_min, espera_max)))

# ───────────────────────── Entrada: puerta -> pasillo -> mesa ─────────────────────────
func _entrar() -> void:
	_detener_tween()
	colision.set_deferred("disabled", false)
	visible = true
	reiniciar()                       # tipo de cliente nuevo
	if not _hay_waypoints():
		global_position = posicion_mesa
		estado = Estado.SENTADO
		return
	var pasillo := nodo_pasillo.global_position
	global_position = nodo_puerta.global_position
	estado = Estado.ENTRANDO
	_tween = create_tween()
	_tween.tween_property(self, "global_position", pasillo, _duracion(global_position, pasillo))
	_tween.tween_property(self, "global_position", posicion_mesa, _duracion(pasillo, posicion_mesa))
	_tween.tween_callback(_on_entrada_terminada)

func _on_entrada_terminada() -> void:
	global_position = posicion_mesa
	estado = Estado.SENTADO

# ───────────────────────── Utilidades ─────────────────────────
func _hay_waypoints() -> bool:
	if nodo_puerta == null or nodo_pasillo == null:
		push_warning("%s: asigna nodo_puerta y nodo_pasillo en el Inspector para que camine." % name)
		return false
	return true

func _duracion(desde: Vector3, hasta: Vector3) -> float:
	return maxf(0.05, desde.distance_to(hasta) / maxf(0.1, velocidad_caminar))

func _detener_tween() -> void:
	if _tween != null and _tween.is_valid():
		_tween.kill()
	_tween = null

func _vaciar_burbuja() -> void:
	burbuja.text = ""

func _paladar() -> String:
	if tolerancia < 0.3:
		return "fino"
	if tolerancia >= 0.5:
		return "poco fino"
	return "normal"
