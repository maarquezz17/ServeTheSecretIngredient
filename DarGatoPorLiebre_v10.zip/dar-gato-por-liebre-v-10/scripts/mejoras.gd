extends "res://scripts/interactuable.gd"
# Pizarra de mejoras de la taberna. Contiene el estado y los efectos de cada mejora.

@export var precio_olla_doble: int = 120
@export var precio_cortinas: int = 80
@export_range(0.0, 1.0, 0.05) var multiplicador_cortinas: float = 0.4

var olla_doble := false
var cortinas := false

@onready var olla2 = get_node("../Olla2")
@onready var nodo_cortinas: Node3D = get_node("../../Callejon/Cortinas")

func _ready() -> void:
	super()
	tipo = "mejoras"
	nodo_cortinas.visible = false

func get_prompt() -> String:
	return "E: Mejoras de la taberna"

func precio(id: String) -> int:
	if id == "olla_doble":
		return precio_olla_doble
	return precio_cortinas

func ya_comprada(id: String) -> bool:
	if id == "olla_doble":
		return olla_doble
	return cortinas

func aplicar(id: String) -> void:
	if id == "olla_doble":
		olla_doble = true
		olla2.set_activa(true)
	else:
		cortinas = true
		nodo_cortinas.visible = true

# Multiplicador de la sospecha pasiva al atrapar gatos (1.0 = sin cortinas).
func multiplicador_captura() -> float:
	if cortinas:
		return multiplicador_cortinas
	return 1.0

func estado() -> Dictionary:
	return {
		"olla_doble": olla_doble, "cortinas": cortinas,
		"precio_olla_doble": precio_olla_doble, "precio_cortinas": precio_cortinas
	}
