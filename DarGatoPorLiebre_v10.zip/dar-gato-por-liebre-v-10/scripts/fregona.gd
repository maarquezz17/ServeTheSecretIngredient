extends "res://scripts/interactuable.gd"
# Fregona apoyada en la pared de la cocina. Al interactuar, el jugador la equipa (game.gd) y desaparece de la pared.

var equipada := false

@onready var colision: CollisionShape3D = $Colision

func _ready() -> void:
	super()
	tipo = "fregona"

func get_prompt() -> String:
	return "E: Coger la fregona"

func equipar() -> void:
	equipada = true
	visible = false
	colision.set_deferred("disabled", true)
