extends "res://scripts/interactuable.gd"
# Olla de cocina. "sospecha_acumulada" (0.0 - 1.0) es la sospecha del guiso: empieza igual a la
# proporción de gato y las especias la reducen.

@export var activa_al_inicio: bool = true

var raciones := 0
var pct_gato := 0.0
var sospecha_acumulada := 0.0
var activa := true
var bloqueo_restante := 0.0
var es_servicio := false

@onready var sopa: MeshInstance3D = $Sopa
@onready var estado: Label3D = $Estado
@onready var colision: CollisionShape3D = $Colision

func _ready() -> void:
	super()
	tipo = "olla"
	add_to_group("ollas")
	set_activa(activa_al_inicio)

func _process(delta: float) -> void:
	if bloqueo_restante > 0.0:
		bloqueo_restante = maxf(0.0, bloqueo_restante - delta)
		_refrescar()

func get_prompt() -> String:
	if bloqueada():
		return "Olla bloqueada por la mafia (%d s)" % int(ceil(bloqueo_restante))
	if raciones > 0:
		return "E: Elegir esta olla para servir / echar especia"
	return "E: Cocinar guiso"

func set_activa(valor: bool) -> void:
	activa = valor
	visible = valor
	colision.set_deferred("disabled", not valor)
	_refrescar()

func bloqueada() -> bool:
	return bloqueo_restante > 0.0

func bloquear(segundos: float) -> void:
	bloqueo_restante = segundos
	_refrescar()

func cocinar(total_raciones: int, proporcion_gato: float) -> void:
	raciones = total_raciones
	pct_gato = proporcion_gato
	sospecha_acumulada = proporcion_gato
	_refrescar()

func reducir_sospecha(cantidad: float) -> void:
	sospecha_acumulada = maxf(0.0, sospecha_acumulada - cantidad)
	_refrescar()

func servir_racion() -> void:
	raciones = maxi(0, raciones - 1)
	_refrescar()

func marcar_servicio(valor: bool) -> void:
	es_servicio = valor
	_refrescar()

func _refrescar() -> void:
	sopa.visible = raciones > 0
	if bloqueada():
		estado.text = "BLOQUEADA %d s" % int(ceil(bloqueo_restante))
	elif raciones > 0:
		var marca := "[SERVICIO] " if es_servicio else ""
		estado.text = "%sGuiso: %d raciones\n%d%% gato · sospecha %d%%" % [marca, raciones, int(round(pct_gato * 100.0)), int(round(sospecha_acumulada * 100.0))]
	else:
		estado.text = "Olla vacía"
