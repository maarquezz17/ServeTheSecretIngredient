extends Area3D
# Mancha (huella de barro/sangre) del pool pre-colocado en Tavern.tscn.
# Cuelga de un MeshInstance3D (su padre) que se muestra/oculta; este Area3D es lo que detecta el raycast.
# CharacterBody3D/Area3D no pueden heredar de interactuable.gd (StaticBody3D), así que cumple su misma interfaz.

signal interactuado(objeto)

@export var tipo: String = "mancha"

var activa := false

@onready var malla: MeshInstance3D = get_parent()
@onready var colision: CollisionShape3D = $Colision

func _ready() -> void:
	add_to_group("interactuable")
	add_to_group("manchas")
	desactivar()

func get_prompt() -> String:
	var jugador = get_tree().get_first_node_in_group("jugador")
	if jugador != null and jugador.fregona_equipada:
		return "E: Limpiar la mancha"
	return "Mancha sospechosa (necesitas la fregona de la cocina)"

func interactuar() -> void:
	interactuado.emit(self)

func activar() -> void:
	activa = true
	malla.visible = true
	colision.set_deferred("disabled", false)

func desactivar() -> void:
	activa = false
	malla.visible = false
	colision.set_deferred("disabled", true)

func limpiar() -> void:
	desactivar()
