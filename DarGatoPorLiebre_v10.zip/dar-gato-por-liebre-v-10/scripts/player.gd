extends CharacterBody3D

const VELOCIDAD := 4.5
const GRAVEDAD := 20.0
const SENSIBILIDAD := 0.0025

@onready var camara: Camera3D = $Camara
@onready var rayo: RayCast3D = $Camara/Rayo
@onready var mano_fregona: Node3D = $Camara/FregonaMano

var controles_activos := true
var objetivo: Node = null
var fregona_equipada := false

func _ready() -> void:
	add_to_group("jugador")
	mano_fregona.visible = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _unhandled_input(event: InputEvent) -> void:
	if not controles_activos:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * SENSIBILIDAD)
		camara.rotate_x(-event.relative.y * SENSIBILIDAD)
		camara.rotation.x = clampf(camara.rotation.x, -1.4, 1.4)
	elif event.is_action_pressed("interact") and objetivo != null:
		objetivo.interactuar()

func _physics_process(delta: float) -> void:
	_actualizar_objetivo()
	if not controles_activos:
		velocity = Vector3.ZERO
		return
	if not is_on_floor():
		velocity.y -= GRAVEDAD * delta
	else:
		velocity.y = 0.0
	var dir := Input.get_vector("move_left", "move_right", "move_forward", "move_backward")
	var mov := (transform.basis * Vector3(dir.x, 0.0, dir.y)).normalized()
	velocity.x = mov.x * VELOCIDAD
	velocity.z = mov.z * VELOCIDAD
	move_and_slide()

func _actualizar_objetivo() -> void:
	objetivo = null
	if rayo.is_colliding():
		var c = rayo.get_collider()
		if c != null and c.has_method("interactuar"):
			objetivo = c

func set_controles(activos: bool) -> void:
	controles_activos = activos

func equipar_fregona() -> void:
	fregona_equipada = true
	mano_fregona.visible = true
