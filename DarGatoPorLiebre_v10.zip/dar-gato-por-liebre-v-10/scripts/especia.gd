extends "res://scripts/interactuable.gd"
# Frasco del estante de especias. Se compra con E y se guarda en el almacén; las especias guardadas
# se echan desde el menú de la olla (antes de cocinar o sobre un guiso ya hecho).

@export var nombre: String = "Romero"
@export_range(0.0, 1.0, 0.05) var reduccion: float = 0.2
@export var precio: int = 3

func _ready() -> void:
	super()
	tipo = "especia"
	add_to_group("especias")

func get_prompt() -> String:
	return "E: Comprar y guardar %s (%d monedas, -%d%% sospecha del guiso)" % [nombre, precio, int(round(reduccion * 100.0))]
