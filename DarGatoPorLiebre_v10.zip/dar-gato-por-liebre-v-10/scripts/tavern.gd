extends Node3D

@onready var olla = $Cocina/Olla
@onready var olla2 = $Cocina/Olla2
@onready var pizarra = $Cocina/Pizarra
@onready var cobrador = $Mafia/Cobrador
@onready var luces: Node3D = $Luces
@onready var sol: DirectionalLight3D = $Luces/Sol

var _energia_base := {}
var _tiempo := 0.0

func _ready() -> void:
	for l in luces.get_children():
		if l is OmniLight3D:
			_energia_base[l] = l.light_energy

func _process(delta: float) -> void:
	_tiempo += delta
	var i := 0
	for l in _energia_base.keys():
		l.light_energy = _energia_base[l] * (1.0 + 0.07 * sin(_tiempo * 6.0 + float(i) * 1.7))
		i += 1

# Nuevo día: reaparecen los gatos. Los clientes se gestionan solos (salen y vuelven a entrar, ver cliente.gd).
func reiniciar_dia() -> void:
	get_tree().call_group("gatos", "reaparecer")

func todos_atendidos() -> bool:
	for c in get_tree().get_nodes_in_group("clientes"):
		if not c.atendido:
			return false
	return true
