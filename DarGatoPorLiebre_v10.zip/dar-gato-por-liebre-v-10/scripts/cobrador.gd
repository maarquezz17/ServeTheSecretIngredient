extends CharacterBody3D
# Cobrador de la Mafia. Aparece ante la puerta principal cuando se agota "tiempo_deuda" (en game.gd).
# Cumple la misma interfaz que interactuable.gd (CharacterBody3D no puede heredar de StaticBody3D).

signal interactuado(objeto)

@export var tipo: String = "cobrador"
@export var prompt: String = "E: Hablar con el cobrador de la mafia"

var presente := false

@onready var colision: CollisionShape3D = $Colision

func _ready() -> void:
	add_to_group("interactuable")
	ocultar()

func get_prompt() -> String:
	return prompt

func interactuar() -> void:
	interactuado.emit(self)

func aparecer() -> void:
	presente = true
	visible = true
	colision.set_deferred("disabled", false)

func ocultar() -> void:
	presente = false
	visible = false
	colision.set_deferred("disabled", true)
