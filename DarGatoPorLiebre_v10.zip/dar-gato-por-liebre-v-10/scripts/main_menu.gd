extends Control
# Menú principal: escena inicial del juego.

const ESCENA_JUEGO := "res://scenes/Main.tscn"

@onready var boton_jugar: Button = $Botones/BotonJugar
@onready var boton_cargar: Button = $Botones/BotonCargar
@onready var boton_ajustes: Button = $Botones/BotonAjustes
@onready var boton_salir: Button = $Botones/BotonSalir

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	boton_jugar.pressed.connect(_on_jugar_pressed)
	boton_cargar.pressed.connect(_on_cargar_pressed)
	boton_ajustes.pressed.connect(_on_ajustes_pressed)
	boton_salir.pressed.connect(_on_salir_pressed)
	boton_jugar.grab_focus()

func _on_jugar_pressed() -> void:
	get_tree().change_scene_to_file(ESCENA_JUEGO)

func _on_cargar_pressed() -> void:
	print("Cargar partida: pendiente de implementar")

func _on_ajustes_pressed() -> void:
	print("Ajustes: pendiente de implementar")

func _on_salir_pressed() -> void:
	get_tree().quit()
