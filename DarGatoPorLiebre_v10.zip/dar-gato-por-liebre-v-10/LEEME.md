# Dar Gato Por Liebre — v10 (Godot 4.7.2)

Abre `project.godot` y pulsa F5: el juego arranca en el **menú principal** (`scenes/MainMenu.tscn`).
La resolución base es 1920×1080 (la interfaz se diseñó para 1280×720, por eso `window/stretch/scale = 1.5`).

## Novedades de esta versión
| Qué | Dónde |
|---|---|
| Menú principal (Jugar nueva partida / Cargar partida / Ajustes / Salir) | scenes/MainMenu.tscn + scripts/main_menu.gd |
| HUD reducido (Día, Monedas, Deuda, barra de Suspicacia, cobrador) | UI.tscn > HUD |
| Reloj grande arriba a la derecha (HH:MM) | UI.tscn > LabelReloj |
| Inventario oculto (se ve mientras mantienes Q) | UI.tscn > PanelInventario |
| Ciclo de día y noche (08:00 → 00:00) | scripts/game.gd (hora, luz del sol y ambiente) |
| Fregona apoyada en la pared izquierda de la cocina | Tavern.tscn > Cocina/Fregona + scripts/fregona.gd |
| Pool de 5 manchas/huellas | Tavern.tscn > Manchas/Mancha1..5 (cada una con un Area3D "Zona") + scripts/mancha.gd |
| Fregona en la mano del jugador | Player.tscn > Camara/FregonaMano |

## Cómo funciona
- **Menú:** "Jugar nueva partida" carga Main.tscn; "Salir" cierra el juego; "Cargar partida" y "Ajustes" solo imprimen un mensaje por ahora.
  En la pantalla final hay un botón "Menú principal".
- **Reloj:** el día empieza a las 08:00 y termina a las 00:00. Un día dura (hora_fin - hora_inicio) × segundos_por_hora (por defecto 16 × 30 s = 8 min).
  A medianoche empieza un día nuevo (clientes y gatos se reinician). Al avanzar la tarde baja la luz del sol y el ambiente.
- **Inventario:** mantén **Q** para ver gatos, liebres, especias, fregona y manchas pendientes. Se oculta al soltar y no se superpone a otros menús.
- **Manchas:** el pool está pre-colocado y oculto (`visible = false`, colisión desactivada). Cada vez que cocinas o consigues carne de gato se muestra una mancha al azar.
  Mientras haya manchas visibles la suspicacia sube sola (`sospecha_por_mancha_seg` por mancha y segundo).
  Coge la fregona (E) y apunta a una mancha (E) para ocultarla: baja la suspicacia (`reduccion_sospecha_limpieza`).
- Nada se crea por código: solo se alterna visibilidad y colisión de nodos ya presentes en las escenas.

## Clientes que entran y salen caminando (v10)
- Tras comer, el cliente espera `tiempo_comiendo`, se levanta y camina **mesa → pasillo → puerta** con dos Tweens lineales encadenados
  (sin NavMesh). Al llegar a la puerta se oculta, desactiva su colisión y arranca su `Timer` (`TimerEspera`, entre `espera_min` y `espera_max` segundos).
  Cuando el Timer acaba reaparece en la puerta con un `TipoCliente` nuevo y camina **puerta → pasillo → su mesa** (`posicion_mesa`, guardada al empezar).
- Mientras camina no se le puede servir ("Cliente en camino").
- Waypoints editables en el viewport: `Tavern > Waypoints` (`Puerta` y `Pasillo1..4`, nodos Marker3D). Cada cliente tiene asignados
  `nodo_puerta` y `nodo_pasillo` en el Inspector. Si mueves una mesa, mueve también su pasillo para que la ruta siga libre.
- Los pasillos están elegidos para no cruzar mesas, sillas ajenas ni otros clientes (comprobado automáticamente).
- Si un cliente tiene vacíos `nodo_puerta` o `nodo_pasillo`, no camina: desaparece y vuelve directamente a su mesa (y avisa en la consola).
- El "servicio completado" (baja la suspicacia) ahora se cuenta por clientes servidos: al servir tantos como clientes hay.
  Los clientes ya no se reinician todos a la vez ni al amanecer: cada uno se recicla solo.

## Editar a mano
- Las manchas están ocultas en el .tscn tal como se pidió: para verlas en el viewport, activa el ojo de `Manchas/ManchaN` y, si quieres probarlo en juego, deja `visible` como estaba.
  Puedes moverlas, rotarlas o cambiarles el material; su Area3D (`Zona`) cuelga de cada una.
- Parámetros de equilibrio (reloj, manchas, deuda, precios…): selecciona el nodo `Main` y edita sus variables exportadas.
- Nombres que los scripts esperan: Cocina/Olla, Cocina/Olla2, Cocina/Pizarra, Cocina/Fregona, Callejon/Cortinas, Mafia/Cobrador, Manchas, Waypoints, Comedor/ClienteN/TimerEspera, Luces/Sol, Camara/FregonaMano.
- Las zonas de detección de las trampas están en la capa de colisión 0 para que no tapen el raycast del jugador (siguen detectando gatos por su máscara).

## Cómo se juega
WASD mover · ratón mirar · E interactuar · Q inventario (mantener) · Esc cerrar menú.
- Gatos: atrápalos a mano (a menudo se escapan) o espera a que caigan en una trampa-jaula y recógela.
- Especias: compra en el estante; se guardan y se echan desde el menú de la olla (antes de cocinar o sobre un guiso hecho).
- Clientes: NORMAL, BORRACHO (impacto 0) o INSPECTOR (sombrero, impacto x3). Se asignan al azar.
- Cobrador: al agotarse `tiempo_deuda` aparece ante la puerta: "Pagar $X" o "Entregar Guiso" (liebre pura te perdona el interés; con gato sube la deuda y bloquea la olla 30 s).
- Pizarra: Olla Doble y Cortinas del callejón.
Ganas saldando la deuda; pierdes con 100 % de suspicacia o si la deuda llega a `deuda_limite`.
